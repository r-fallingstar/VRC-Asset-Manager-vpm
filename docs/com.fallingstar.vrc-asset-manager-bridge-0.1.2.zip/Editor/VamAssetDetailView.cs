using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace VrcAssetManager.Bridge
{
    // 導入済みアセットの詳細表示（Inspector に表示する）
    public static class VamAssetDetailView
    {
        private static readonly Dictionary<string, Texture2D> ThumbCache = new Dictionary<string, Texture2D>(StringComparer.OrdinalIgnoreCase);

        private static bool IsDark => EditorGUIUtility.isProSkin;
        private static Color Surface2Color => VamTheme.Surface;
        private static Color MutedColor => VamTheme.Muted;

        private static string _assetFilter = "all";

        public static InstalledAssetRecord FindRecord(InstalledManifest manifest, string itemId)
        {
            if (manifest?.assets == null || string.IsNullOrEmpty(itemId)) return null;
            return manifest.assets.FirstOrDefault(a => string.Equals(a.itemId, itemId, StringComparison.OrdinalIgnoreCase));
        }

        // root に itemId の詳細を描画する。記録が無ければ案内を表示する
        public static void Render(VisualElement root, string itemId)
        {
            root.Clear();
            root.style.paddingLeft = 4;
            root.style.paddingRight = 4;
            root.style.paddingTop = 6;
            root.style.paddingBottom = 10;

            var manifest = VamManifestStore.LoadCached();
            var rec = FindRecord(manifest, itemId);
            if (rec == null)
            {
                var gone = new Label("このアセットの記録が見つかりません（削除された可能性があります）。");
                gone.style.color = MutedColor;
                gone.style.whiteSpace = WhiteSpace.Normal;
                root.Add(gone);
                return;
            }
            var _detailScroll = root;

            string cat = string.IsNullOrEmpty(rec.categoryLabel) ? rec.category : rec.categoryLabel;
            var catBadge = new Label(string.IsNullOrEmpty(cat) ? "アセット" : cat);
            catBadge.style.fontSize = 11;
            catBadge.style.color = MutedColor;
            catBadge.style.unityFontStyleAndWeight = FontStyle.Bold;
            catBadge.style.marginBottom = 6;
            _detailScroll.Add(catBadge);

            // Large thumb
            if (!string.IsNullOrEmpty(rec.thumbPath))
            {
                var img = new Image { scaleMode = ScaleMode.ScaleToFit };
                img.style.height = 200;
                img.style.marginBottom = 8;
                img.style.backgroundColor = Surface2Color;
                img.style.borderTopLeftRadius = 3;
                img.style.borderTopRightRadius = 3;
                img.style.borderBottomLeftRadius = 3;
                img.style.borderBottomRightRadius = 3;
                _detailScroll.Add(img);
                RequestThumbnail(rec.thumbPath, t =>
                {
                    if (t != null) img.image = t;
                    else img.style.display = DisplayStyle.None;
                });
            }

            var titleLbl = new Label(VamTheme.Display(rec.title));
            titleLbl.style.fontSize = 14;
            titleLbl.style.unityFontStyleAndWeight = FontStyle.Bold;
            titleLbl.style.whiteSpace = WhiteSpace.Normal;
            titleLbl.style.marginBottom = 4;
            _detailScroll.Add(titleLbl);

            string metaText = $"ショップ: {(string.IsNullOrEmpty(rec.shop) ? "-" : VamTheme.Display(rec.shop))}";
            if (!string.IsNullOrEmpty(rec.version)) metaText += $"  |  Ver: {rec.version}";
            if (rec.installedAt > 0)
            {
                var dt = DateTimeOffset.FromUnixTimeSeconds(rec.installedAt).LocalDateTime;
                metaText += $"\n導入日時: {dt:yyyy/MM/dd HH:mm}（{(rec.detectedBy == "scan" ? "自動検出" : "インポート")}）";
            }
            var metaLbl = new Label(metaText);
            metaLbl.style.fontSize = 11;
            metaLbl.style.color = MutedColor;
            metaLbl.style.whiteSpace = WhiteSpace.Normal;
            metaLbl.style.marginBottom = 8;
            _detailScroll.Add(metaLbl);

            // Action Buttons
            var actRow = new VisualElement();
            actRow.style.flexDirection = FlexDirection.Row;
            actRow.style.flexWrap = Wrap.Wrap;
            actRow.style.marginBottom = 8;

            var folderBtn = new Button(() => InstalledAssetsWindow.RevealAssetFolder(rec)) { text = "プロジェクトのフォルダを表示" };
            folderBtn.style.marginRight = 4;
            folderBtn.style.marginBottom = 4;
            actRow.Add(folderBtn);

            if (!string.IsNullOrEmpty(rec.boothUrl) &&
                (rec.boothUrl.StartsWith("https://", StringComparison.OrdinalIgnoreCase) ||
                 rec.boothUrl.StartsWith("http://", StringComparison.OrdinalIgnoreCase)))
            {
                var boothBtn = new Button(() => Application.OpenURL(rec.boothUrl)) { text = "BOOTHを開く" };
                boothBtn.style.marginRight = 4;
                boothBtn.style.marginBottom = 4;
                actRow.Add(boothBtn);
            }

            if (!string.IsNullOrEmpty(rec.itemId) || !string.IsNullOrEmpty(rec.boothId))
            {
                var vamBtn = new Button(() => OpenInVam(rec)) { text = "VAMで開く" };
                vamBtn.tooltip = "VRC Asset Manager でこのアイテムの詳細を開きます";
                vamBtn.style.marginRight = 4;
                vamBtn.style.marginBottom = 4;
                actRow.Add(vamBtn);
            }

            if (!string.IsNullOrWhiteSpace(rec.memo))
            {
                var copyBtn = new Button(() =>
                {
                    EditorGUIUtility.systemCopyBuffer = rec.memo;
                    InstalledAssetsWindow.Notify("メモをコピーしました");
                }) { text = "メモをコピー" };
                copyBtn.style.marginRight = 4;
                copyBtn.style.marginBottom = 4;
                actRow.Add(copyBtn);
            }

            var uninstBtn = new Button(() =>
            {
                if (ConfirmAndUninstall(manifest, rec)) Render(root, itemId);
            }) { text = "アンインストール…" };
            uninstBtn.style.color = VamTheme.Danger;
            uninstBtn.style.marginBottom = 4;
            actRow.Add(uninstBtn);
            _detailScroll.Add(actRow);

            // Memo
            if (!string.IsNullOrWhiteSpace(rec.memo))
            {
                var memoTitle = new Label("マイメモ");
                memoTitle.style.fontSize = 11;
                memoTitle.style.unityFontStyleAndWeight = FontStyle.Bold;
                memoTitle.style.marginBottom = 3;
                _detailScroll.Add(memoTitle);

                var memoBox = new Label(VamTheme.Display(rec.memo));
                memoBox.style.fontSize = 11;
                memoBox.style.whiteSpace = WhiteSpace.Normal;
                memoBox.style.paddingLeft = 8;
                memoBox.style.paddingRight = 8;
                memoBox.style.paddingTop = 6;
                memoBox.style.paddingBottom = 6;
                memoBox.style.backgroundColor = Surface2Color;
                memoBox.style.borderTopLeftRadius = 3;
                memoBox.style.borderTopRightRadius = 3;
                memoBox.style.borderBottomLeftRadius = 3;
                memoBox.style.borderBottomRightRadius = 3;
                memoBox.style.marginBottom = 10;
                _detailScroll.Add(memoBox);
            }

            // Live project assets
            var livePaths = VamManifestStore.ResolveLivePaths(rec);
            var assetTitle = new Label($"プロジェクト内のファイル ({livePaths.Count} 件)");
            assetTitle.style.fontSize = 11;
            assetTitle.style.unityFontStyleAndWeight = FontStyle.Bold;
            assetTitle.style.marginBottom = 4;
            _detailScroll.Add(assetTitle);

            var filterRow = new VisualElement();
            filterRow.style.flexDirection = FlexDirection.Row;
            filterRow.style.flexWrap = Wrap.Wrap;
            filterRow.style.marginBottom = 6;

            var filters = new[]
            {
                ("all", "すべて"),
                ("prefab", "Prefab"),
                ("mat", "Material"),
                ("model", "Model"),
                ("tex", "Texture"),
                ("folder", "Folder")
            };
            foreach (var (key, label) in filters)
            {
                var fb = new Button(() =>
                {
                    _assetFilter = key;
                    Render(root, itemId);
                }) { text = label };
                fb.style.fontSize = 10;
                fb.style.paddingLeft = 6;
                fb.style.paddingRight = 6;
                fb.style.marginRight = 3;
                fb.style.marginBottom = 3;
                if (_assetFilter == key)
                {
                    fb.style.backgroundColor = VamTheme.Selection;
                    fb.style.color = VamTheme.SelectionText;
                }
                filterRow.Add(fb);
            }
            _detailScroll.Add(filterRow);

            var filteredPaths = livePaths.Where(MatchesAssetFilter).ToList();
            if (filteredPaths.Count == 0)
            {
                var noAssets = new Label("表示できるファイルがありません（クリックでPing・ドラッグでSceneへ配置できます）");
                noAssets.style.fontSize = 11;
                noAssets.style.color = MutedColor;
                noAssets.style.whiteSpace = WhiteSpace.Normal;
                _detailScroll.Add(noAssets);
                return;
            }

            int shown = 0;
            foreach (var assetPath in filteredPaths)
            {
                if (shown >= 150)
                {
                    var more = new Label($"他 {filteredPaths.Count - shown} 件は省略されています（Project 窓でご確認ください）");
                    more.style.fontSize = 10;
                    more.style.color = MutedColor;
                    more.style.marginTop = 4;
                    _detailScroll.Add(more);
                    break;
                }
                _detailScroll.Add(CreateAssetRow(assetPath));
                shown++;
            }
        }

        private static bool MatchesAssetFilter(string assetPath)
        {
            if (_assetFilter == "all") return true;
            bool isFolder = AssetDatabase.IsValidFolder(assetPath);
            if (_assetFilter == "folder") return isFolder;
            if (isFolder) return false;

            string ext = Path.GetExtension(assetPath).ToLowerInvariant();
            switch (_assetFilter)
            {
                case "prefab": return ext == ".prefab";
                case "mat": return ext == ".mat";
                case "model": return ext == ".fbx" || ext == ".obj" || ext == ".blend";
                case "tex": return ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".tga" || ext == ".psd";
                default: return true;
            }
        }

        private static VisualElement CreateAssetRow(string assetPath)
        {
            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.alignItems = Align.Center;
            row.style.paddingLeft = 6;
            row.style.paddingRight = 6;
            row.style.paddingTop = 3;
            row.style.paddingBottom = 3;
            row.style.marginBottom = 2;
            row.style.backgroundColor = Surface2Color;
            row.style.borderTopLeftRadius = 4;
            row.style.borderTopRightRadius = 4;
            row.style.borderBottomLeftRadius = 4;
            row.style.borderBottomRightRadius = 4;
            row.tooltip = assetPath + "\nクリック: Project で選択 / ダブルクリック: 開く / ドラッグ: Scene へ配置";

            // 一覧表示ではアセット本体を読み込まない（FBX やテクスチャの読み込みで重くなるため）。
            // アイコンはキャッシュから取り、本体はクリック・ドラッグしたときに読み込む
            UnityEngine.Object obj = null;
            UnityEngine.Object GetObj() => obj != null ? obj : (obj = AssetDatabase.LoadMainAssetAtPath(assetPath));
            var iconTex = AssetDatabase.GetCachedIcon(assetPath);
            if (iconTex != null)
            {
                var ic = new Image { image = iconTex, scaleMode = ScaleMode.ScaleToFit };
                ic.style.width = 16;
                ic.style.height = 16;
                ic.style.marginRight = 6;
                ic.style.flexShrink = 0;
                row.Add(ic);
            }

            string name = Path.GetFileName(assetPath);
            var nameLbl = new Label(name);
            nameLbl.style.fontSize = 11;
            nameLbl.style.flexGrow = 1;
            nameLbl.style.overflow = Overflow.Hidden;
            nameLbl.style.textOverflow = TextOverflow.Ellipsis;
            row.Add(nameLbl);

            Vector2 pressPos = Vector2.zero;
            bool dragging = false;

            row.RegisterCallback<PointerDownEvent>(evt =>
            {
                if (evt.button != 0) return;
                pressPos = evt.position;
                dragging = false;
                var o = GetObj();
                if (o == null) return;
                if (evt.clickCount == 2)
                {
                    AssetDatabase.OpenAsset(o);
                }
                else
                {
                    // Inspector の詳細表示を維持したまま、Project ウィンドウで場所を示す
                    EditorGUIUtility.PingObject(o);
                }
            });

            row.RegisterCallback<PointerMoveEvent>(evt =>
            {
                if (dragging) return;
                if ((evt.pressedButtons & 1) == 0) return;
                if (Vector2.Distance(evt.position, pressPos) >= 6f)
                {
                    var o = GetObj();
                    if (o == null) return;
                    dragging = true;
                    DragAndDrop.PrepareStartDrag();
                    DragAndDrop.objectReferences = new[] { o };
                    DragAndDrop.paths = new[] { assetPath };
                    DragAndDrop.StartDrag(o.name);
                    evt.StopPropagation();
                }
            });

            return row;
        }

        // 実際に記録やファイルを変更したら true
        private static bool ConfirmAndUninstall(InstalledManifest _manifest, InstalledAssetRecord rec)
        {
            var analysis = VamManifestStore.AnalyzeUninstall(_manifest, rec);
            int exclCount = analysis.exclusiveFilePaths.Count;
            int sharedCount = analysis.sharedPaths.Count;
            int refCount = analysis.referencedByPaths.Count;

            if (exclCount == 0 && analysis.exclusiveFolderPaths.Count == 0)
            {
                bool removeRecordOnly = EditorUtility.DisplayDialog(
                    "アンインストール確認",
                    $"「{rec.title}」の固有ファイルはプロジェクト内に残っていないか、他のアセットと共有されています（共有保護: {sharedCount} 件）。\n\n「導入済みアセット」一覧の記録だけ削除しますか？",
                    "記録を削除",
                    "キャンセル");
                if (removeRecordOnly)
                {
                    _manifest.assets.RemoveAll(a => string.Equals(a.itemId, rec.itemId, StringComparison.OrdinalIgnoreCase));
                    VamManifestStore.Save(_manifest);
                    InstalledAssetsWindow.NotifyDataChanged();
                }
                return removeRecordOnly;
            }

            string refWarn = refCount > 0
                ? $"\n\n⚠ 注意: 他のシーンや Prefab など {refCount} 件から参照されています：\n・" +
                  string.Join("\n・", analysis.referencedByPaths.Take(5)) +
                  (refCount > 5 ? $"\n（ほか {refCount - 5} 件）" : "")
                : "";

            string msg =
                $"「{rec.title}」をプロジェクトからアンインストールします。\n\n" +
                $"・ゴミ箱へ移動するファイル: {exclCount} 件\n" +
                $"・他アセットと共有のため保護するファイル: {sharedCount} 件" +
                refWarn +
                "\n\nOS のゴミ箱へ移動します。よろしいですか？";

            if (!EditorUtility.DisplayDialog("アセットのアンインストール", msg, "ゴミ箱へ移動して削除", "キャンセル"))
            {
                return false;
            }

            var (removed, failed) = VamManifestStore.ExecuteUninstall(_manifest, rec, analysis);
            InstalledAssetsWindow.NotifyDataChanged();
            if (failed.Count > 0)
            {
                InstalledAssetsWindow.Notify($"{removed} 件削除しました（失敗 {failed.Count} 件）");
            }
            else
            {
                InstalledAssetsWindow.Notify($"「{rec.title}」を削除しました（{removed} 件）");
            }
            return true;
        }

        public static Texture2D LoadThumbnail(string thumbPath)
        {
            if (string.IsNullOrEmpty(thumbPath) || !File.Exists(thumbPath)) return null;
            if (ThumbCache.TryGetValue(thumbPath, out var cached) && cached != null)
            {
                return cached;
            }

            try
            {
                byte[] bytes = File.ReadAllBytes(thumbPath);
                var tex = new Texture2D(2, 2, TextureFormat.RGBA32, false);
                if (ImageConversion.LoadImage(tex, bytes, false))
                {
                    tex.hideFlags = HideFlags.HideAndDontSave;
                    ThumbCache[thumbPath] = tex;
                    return tex;
                }
                UnityEngine.Object.DestroyImmediate(tex);
            }
            catch
            {
                // Ignore corrupted thumbnails
            }
            return null;
        }

        [Serializable]
        private class AppInstanceInfo
        {
            public string exePath = "";
        }

        // VRC Asset Manager を起動（起動中なら前面に出して）このアイテムの詳細を開く
        public static void OpenInVam(InstalledAssetRecord rec)
        {
            string exe = FindVamExe();
            if (string.IsNullOrEmpty(exe))
            {
                EditorUtility.DisplayDialog("VAMで開く", "VRC Asset Manager が見つかりません。一度 VRC Asset Manager を起動してから、もう一度お試しください。", "OK");
                return;
            }

            var args = new List<string>();
            if (!string.IsNullOrEmpty(rec.itemId)) { args.Add("--open-item"); args.Add(rec.itemId); }
            if (!string.IsNullOrEmpty(rec.boothId)) { args.Add("--booth"); args.Add(rec.boothId); }
            try
            {
                var psi = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = exe,
                    Arguments = string.Join(" ", args.Select(QuoteArg)),
                    UseShellExecute = false,
                    WorkingDirectory = Path.GetDirectoryName(exe) ?? "",
                };
                System.Diagnostics.Process.Start(psi);
            }
            catch (Exception ex)
            {
                EditorUtility.DisplayDialog("VAMで開く", "VRC Asset Manager を起動できませんでした：\n" + ex.Message, "OK");
            }
        }

        // VRC Asset Manager の実行ファイル（最後に起動した版。無ければ通常のインストール先）
        public static string FindVamExe()
        {
            string exe = "";
            try
            {
                string info = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "VRC Asset Manager", "app_instance.json");
                if (File.Exists(info))
                {
                    exe = JsonUtility.FromJson<AppInstanceInfo>(File.ReadAllText(info))?.exePath ?? "";
                }
            }
            catch
            {
                exe = "";
            }
            if (string.IsNullOrEmpty(exe) || !File.Exists(exe))
            {
                string installed = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "VRC Asset Manager", "VRCAssetManager.exe");
                if (File.Exists(installed)) exe = installed;
            }
            return !string.IsNullOrEmpty(exe) && File.Exists(exe) ? exe : "";
        }

        [Serializable]
        private class SyncResult
        {
#pragma warning disable 0649 // JsonUtility が値を入れる
            public bool ok;
            public string message = "";
            public int total;
            public int matched;
            public bool changed;
#pragma warning restore 0649
        }

        private static bool _syncRunning;

        // VRC Asset Manager にこのプロジェクトの導入記録を最新のジャンル・タイトル・ショップ・サムネイルに更新してもらう。
        // アプリはウィンドウを出さずに処理して終了する（--sync-unity）。処理は別スレッドで待つので Unity は止まらない
        public static void SyncWithVam(Action<bool, string> onDone)
        {
            if (_syncRunning) return;
            string exe = FindVamExe();
            if (string.IsNullOrEmpty(exe))
            {
                onDone?.Invoke(false, "VRC Asset Manager が見つかりません。一度 VRC Asset Manager を起動してから、もう一度お試しください。");
                return;
            }
            _syncRunning = true;
            string project = VamManifestStore.ProjectRoot;
            string stdout = "", stderr = "";
            int code = -1;
            Exception error = null;
            var thread = new System.Threading.Thread(() =>
            {
                try
                {
                    var psi = new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = exe,
                        Arguments = "--sync-unity " + QuoteArg(project),
                        UseShellExecute = false,
                        CreateNoWindow = true,
                        RedirectStandardOutput = true,
                        RedirectStandardError = true,
                        StandardOutputEncoding = System.Text.Encoding.UTF8,
                        WorkingDirectory = Path.GetDirectoryName(exe) ?? "",
                    };
                    using (var p = System.Diagnostics.Process.Start(psi))
                    {
                        stdout = p.StandardOutput.ReadToEnd();
                        stderr = p.StandardError.ReadToEnd();
                        if (!p.WaitForExit(120000))
                        {
                            try { p.Kill(); } catch { }
                        }
                        code = p.HasExited ? p.ExitCode : -1;
                    }
                }
                catch (Exception ex)
                {
                    error = ex;
                }
                EditorApplication.delayCall += () =>
                {
                    _syncRunning = false;
                    if (error != null)
                    {
                        onDone?.Invoke(false, "VRC Asset Manager を起動できませんでした：" + error.Message);
                        return;
                    }
                    SyncResult res = null;
                    string line = (stdout ?? "").Split('\n').Select(l => l.Trim()).LastOrDefault(l => l.StartsWith("{"));
                    try { if (!string.IsNullOrEmpty(line)) res = JsonUtility.FromJson<SyncResult>(line); } catch { res = null; }
                    if (res == null)
                    {
                        onDone?.Invoke(false, "同期できませんでした（VRC Asset Manager が古い可能性があります。最新版に更新してください）" + (string.IsNullOrWhiteSpace(stderr) ? "" : "\n" + stderr.Trim()));
                        return;
                    }
                    if (!res.ok)
                    {
                        onDone?.Invoke(false, res.message);
                        return;
                    }
                    onDone?.Invoke(true, res.changed
                        ? $"VAM と同期しました（{res.matched} / {res.total} 件をライブラリーと照合）"
                        : $"すでに最新です（{res.matched} / {res.total} 件をライブラリーと照合）");
                };
            })
            { IsBackground = true, Name = "VAM-Sync" };
            thread.Start();
        }

        private static string QuoteArg(string s)
        {
            if (string.IsNullOrEmpty(s)) return "\"\"";
            return "\"" + s.Replace("\"", "\\\"") + "\"";
        }

        // ---- サムネイルの非同期読み込み ----
        // ファイル読み込みは別スレッド、デコードはメインスレッドで1フレームあたり数ミリ秒まで。
        // ウィンドウを開いても Unity の操作が止まらないようにする
        private sealed class ThumbRequest
        {
            public string Path;
            public byte[] Bytes;
            public bool Failed;
            public readonly List<Action<Texture2D>> Callbacks = new List<Action<Texture2D>>();
        }

        private static readonly Dictionary<string, ThumbRequest> Pending = new Dictionary<string, ThumbRequest>(StringComparer.OrdinalIgnoreCase);
        private static readonly System.Collections.Concurrent.ConcurrentQueue<ThumbRequest> Ready = new System.Collections.Concurrent.ConcurrentQueue<ThumbRequest>();
        private static bool _pumpRegistered;
        private const int ThumbMaxSize = 320;

        public static void RequestThumbnail(string thumbPath, Action<Texture2D> onLoaded)
        {
            if (string.IsNullOrEmpty(thumbPath))
            {
                onLoaded?.Invoke(null);
                return;
            }
            if (ThumbCache.TryGetValue(thumbPath, out var cached) && cached != null)
            {
                onLoaded?.Invoke(cached);
                return;
            }
            if (Pending.TryGetValue(thumbPath, out var req))
            {
                if (onLoaded != null) req.Callbacks.Add(onLoaded);
                return;
            }
            req = new ThumbRequest { Path = thumbPath };
            if (onLoaded != null) req.Callbacks.Add(onLoaded);
            Pending[thumbPath] = req;
            if (!_pumpRegistered)
            {
                EditorApplication.update += PumpThumbnails;
                _pumpRegistered = true;
            }
            System.Threading.ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    req.Bytes = File.Exists(req.Path) ? File.ReadAllBytes(req.Path) : null;
                }
                catch
                {
                    req.Bytes = null;
                }
                req.Failed = req.Bytes == null;
                Ready.Enqueue(req);
            });
        }

        private static void PumpThumbnails()
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            while (sw.ElapsedMilliseconds < 6 && Ready.TryDequeue(out var req))
            {
                Texture2D tex = null;
                if (!req.Failed)
                {
                    try
                    {
                        var full = new Texture2D(2, 2, TextureFormat.RGBA32, false);
                        if (ImageConversion.LoadImage(full, req.Bytes, false))
                        {
                            tex = Downscale(full, ThumbMaxSize);
                            if (tex != full) UnityEngine.Object.DestroyImmediate(full);
                            tex.hideFlags = HideFlags.HideAndDontSave;
                            ThumbCache[req.Path] = tex;
                        }
                        else
                        {
                            UnityEngine.Object.DestroyImmediate(full);
                        }
                    }
                    catch
                    {
                        tex = null;
                    }
                }
                req.Bytes = null;
                Pending.Remove(req.Path);
                foreach (var cb in req.Callbacks)
                {
                    try
                    {
                        cb(tex);
                    }
                    catch
                    {
                        // 描画先が閉じられていても無視
                    }
                }
            }
            if (Pending.Count == 0 && Ready.IsEmpty)
            {
                EditorApplication.update -= PumpThumbnails;
                _pumpRegistered = false;
            }
        }

        // 大きな画像は GPU で縮小してから保持する（メモリと描画の負荷を減らす）
        private static Texture2D Downscale(Texture2D src, int maxSize)
        {
            int w = src.width, h = src.height;
            if (w <= maxSize && h <= maxSize) return src;
            float s = (float)maxSize / Mathf.Max(w, h);
            int nw = Mathf.Max(1, Mathf.RoundToInt(w * s)), nh = Mathf.Max(1, Mathf.RoundToInt(h * s));
            var rt = RenderTexture.GetTemporary(nw, nh, 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.sRGB);
            var prev = RenderTexture.active;
            try
            {
                Graphics.Blit(src, rt);
                RenderTexture.active = rt;
                var dst = new Texture2D(nw, nh, TextureFormat.RGBA32, false);
                dst.ReadPixels(new Rect(0, 0, nw, nh), 0, 0);
                dst.Apply(false, false);
                return dst;
            }
            finally
            {
                RenderTexture.active = prev;
                RenderTexture.ReleaseTemporary(rt);
            }
        }
    }
}
