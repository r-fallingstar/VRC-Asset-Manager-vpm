# Changelog

## [0.1.0] - 2026-11-26
### Added
- ローカル HTTP ブリッジサーバー (`127.0.0.1` + ランダム認証トークン) による VRC Asset Manager 連携
- `.unitypackage` インポート時の GUID 自動記録 (`ProjectSettings/VRCAssetManagerInstalled.json`) および一時展開ディレクトリの自動後始末
- UI Toolkit ベースの「導入済みアセット」エディタウィンドウ（検索・ジャンル絞り込み・詳細・Ping・ドラッグ＆ドロップ・安全アンインストール）
- VRC Asset Manager 側 GUID スキャン結果との双方向マニフェスト同期 (`/api/sync-manifest`)
