using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using UnityEditor;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace VrcAssetManager.Bridge
{
    [InitializeOnLoad]
    public static class VamBridgeServer
    {
        public const string BridgeVersion = "0.1.0";

        private static readonly UTF8Encoding Utf8NoBom = new UTF8Encoding(false);
        private static readonly ConcurrentQueue<Action> MainThreadQueue = new ConcurrentQueue<Action>();
        private static readonly object JobLock = new object();

        private static HttpListener _listener;
        private static Thread _listenerThread;
        private static volatile bool _running;
        private static int _port;
        private static string _token = "";
        private static long _startedAt;
        private static double _nextHeartbeatTime;

        private static bool _busy;
        private static string _currentJobId = "";
        private static string _currentJobState = "idle";
        private static readonly Dictionary<string, ImportStatusResponse> Jobs = new Dictionary<string, ImportStatusResponse>();

        private static string _activeJobId = "";
        private static InstalledAssetRecord _activeRecord;
        private static string _activeCleanupDir = "";
        private static List<PackageAssetEntry> _activePackageEntries = new List<PackageAssetEntry>();
        private static string _activePackageFileName = "";
        private static bool _hooksRegistered;

        public static bool IsRunning => _running && _port > 0;
        public static int Port => _port;

        static VamBridgeServer()
        {
            StartServer();
            EditorApplication.update += OnEditorUpdate;
            EditorApplication.quitting += StopServer;
            AssemblyReloadEvents.beforeAssemblyReload += StopServer;
        }

        private static string RegistryPath
        {
            get
            {
                string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                return Path.Combine(localAppData, "VRC Asset Manager", "unity_instances.json");
            }
        }

        private static void StartServer()
        {
            if (_running) return;
            try
            {
                _port = FindFreePort();
                _token = Guid.NewGuid().ToString("N");
                _startedAt = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

                _listener = new HttpListener();
                _listener.Prefixes.Add($"http://127.0.0.1:{_port}/");
                _listener.Start();
                _running = true;

                _listenerThread = new Thread(ListenLoop)
                {
                    IsBackground = true,
                    Name = "VAM-Bridge-Http"
                };
                _listenerThread.Start();

                RegisterInstance();
                _nextHeartbeatTime = EditorApplication.timeSinceStartup + 15.0;
            }
            catch (Exception ex)
            {
                _running = false;
                Debug.LogWarning($"[VRC Asset Manager Bridge] Failed to start local server: {ex.Message}");
            }
        }

        private static void StopServer()
        {
            _running = false;
            try
            {
                _listener?.Stop();
                _listener?.Close();
            }
            catch
            {
                // Ignore shutdown exceptions
            }
            _listener = null;
            UnregisterInstance();
        }

        private static int FindFreePort()
        {
            var l = new TcpListener(IPAddress.Loopback, 0);
            l.Start();
            int p = ((IPEndPoint)l.LocalEndpoint).Port;
            l.Stop();
            return p;
        }

        private static void OnEditorUpdate()
        {
            while (MainThreadQueue.TryDequeue(out var action))
            {
                try
                {
                    action?.Invoke();
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[VRC Asset Manager Bridge] MainThread action error: {ex}");
                }
            }

            if (_running && EditorApplication.timeSinceStartup >= _nextHeartbeatTime)
            {
                _nextHeartbeatTime = EditorApplication.timeSinceStartup + 15.0;
                RegisterInstance();
            }
        }

        private static void ListenLoop()
        {
            while (_running && _listener != null)
            {
                try
                {
                    var ctx = _listener.GetContext();
                    ThreadPool.QueueUserWorkItem(_ => HandleContext(ctx));
                }
                catch (HttpListenerException)
                {
                    if (!_running) break;
                }
                catch (ObjectDisposedException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    if (_running)
                    {
                        Debug.LogWarning($"[VRC Asset Manager Bridge] Listener loop error: {ex.Message}");
                    }
                }
            }
        }

        private static void HandleContext(HttpListenerContext ctx)
        {
            try
            {
                string token = ctx.Request.Headers["X-VAM-Token"] ?? "";
                if (!ConstantTimeEquals(token, _token))
                {
                    WriteJson(ctx.Response, 401, new ApiSimpleResponse { ok = false, message = "unauthorized" });
                    return;
                }

                string path = (ctx.Request.Url?.AbsolutePath ?? "/").TrimEnd('/');
                if (string.IsNullOrEmpty(path)) path = "/";
                string method = ctx.Request.HttpMethod.ToUpperInvariant();

                if (method == "GET" && path == "/api/status")
                {
                    var resp = RunOnMainThread(() =>
                    {
                        var manifest = VamManifestStore.Load();
                        lock (JobLock)
                        {
                            return new BridgeStatusResponse
                            {
                                ok = true,
                                projectPath = VamManifestStore.ProjectRoot,
                                projectName = Path.GetFileName(VamManifestStore.ProjectRoot),
                                unityVersion = Application.unityVersion,
                                bridgeVersion = BridgeVersion,
                                installedCount = manifest.assets.Count,
                                busy = _busy,
                                currentJobId = _currentJobId,
                                currentJobState = _currentJobState
                            };
                        }
                    });
                    WriteJson(ctx.Response, 200, resp);
                    return;
                }

                if (method == "GET" && path == "/api/installed")
                {
                    var manifest = RunOnMainThread(VamManifestStore.Load);
                    WriteJson(ctx.Response, 200, manifest);
                    return;
                }

                if (method == "GET" && path == "/api/import-status")
                {
                    string jobId = ctx.Request.QueryString["jobId"] ?? "";
                    ImportStatusResponse st;
                    lock (JobLock)
                    {
                        if (!Jobs.TryGetValue(jobId, out st))
                        {
                            st = new ImportStatusResponse { jobId = jobId, state = "unknown", message = "job not found" };
                        }
                    }
                    WriteJson(ctx.Response, 200, st);
                    return;
                }

                if (method == "POST" && path == "/api/import")
                {
                    string body = ReadBody(ctx.Request);
                    var req = JsonUtility.FromJson<ImportRequestPayload>(body);
                    if (req == null || string.IsNullOrEmpty(req.packagePath) || !File.Exists(req.packagePath))
                    {
                        WriteJson(ctx.Response, 400, new ApiSimpleResponse { ok = false, message = "packagePath not found" });
                        return;
                    }

                    if (string.IsNullOrEmpty(req.jobId))
                    {
                        req.jobId = Guid.NewGuid().ToString("N");
                    }
                    if (req.record == null) req.record = new InstalledAssetRecord();
                    req.record.EnsureLists();

                    lock (JobLock)
                    {
                        if (_busy)
                        {
                            WriteJson(ctx.Response, 409, new ApiSimpleResponse { ok = false, message = "別のパッケージをインポート中です" });
                            return;
                        }
                        _busy = true;
                        _currentJobId = req.jobId;
                        _currentJobState = "queued";
                        Jobs[req.jobId] = new ImportStatusResponse
                        {
                            jobId = req.jobId,
                            state = "queued",
                            message = "インポート準備中…"
                        };
                    }

                    // Parse GUID entries on background thread before calling AssetDatabase.ImportPackage
                    List<PackageAssetEntry> parsedEntries;
                    try
                    {
                        parsedEntries = VamUnityPackageParser.ParseEntries(req.packagePath);
                    }
                    catch (Exception ex)
                    {
                        parsedEntries = new List<PackageAssetEntry>();
                        Debug.LogWarning($"[VRC Asset Manager Bridge] ParseEntries warning: {ex.Message}");
                    }

                    MainThreadQueue.Enqueue(() => BeginImportOnMainThread(req, parsedEntries));
                    WriteJson(ctx.Response, 200, new ImportStatusResponse
                    {
                        jobId = req.jobId,
                        state = "queued",
                        message = "Unity でインポートを開始しました"
                    });
                    return;
                }

                if (method == "POST" && path == "/api/sync-manifest")
                {
                    string body = ReadBody(ctx.Request);
                    var payload = JsonUtility.FromJson<SyncManifestPayload>(body);
                    if (payload == null)
                    {
                        WriteJson(ctx.Response, 400, new ApiSimpleResponse { ok = false, message = "invalid payload" });
                        return;
                    }

                    int total = RunOnMainThread(() =>
                    {
                        var manifest = VamManifestStore.Load();
                        if (payload.assets != null)
                        {
                            foreach (var rec in payload.assets)
                            {
                                VamManifestStore.Upsert(manifest, rec, preferExistingImport: true);
                            }
                        }
                        VamManifestStore.Save(manifest);
                        InstalledAssetsWindow.NotifyDataChanged();
                        return manifest.assets.Count;
                    });
                    WriteJson(ctx.Response, 200, new ApiSimpleResponse { ok = true, count = total, message = "synced" });
                    return;
                }

                if (method == "POST" && path == "/api/open-window")
                {
                    string body = ReadBody(ctx.Request);
                    var payload = !string.IsNullOrWhiteSpace(body) ? JsonUtility.FromJson<OpenWindowPayload>(body) : null;
                    MainThreadQueue.Enqueue(() =>
                    {
                        InstalledAssetsWindow.OpenAndSelect(payload?.itemId, payload?.boothId);
                    });
                    WriteJson(ctx.Response, 200, new ApiSimpleResponse { ok = true, message = "opened" });
                    return;
                }

                WriteJson(ctx.Response, 404, new ApiSimpleResponse { ok = false, message = "not found" });
            }
            catch (Exception ex)
            {
                try
                {
                    WriteJson(ctx.Response, 500, new ApiSimpleResponse { ok = false, message = ex.Message });
                }
                catch
                {
                    // Ignore write errors on closed response
                }
            }
        }

        private static void BeginImportOnMainThread(ImportRequestPayload req, List<PackageAssetEntry> parsedEntries)
        {
            EnsureImportHooks();
            _activeJobId = req.jobId;
            _activeRecord = req.record;
            _activeCleanupDir = req.cleanupTempDir ?? "";
            _activePackageEntries = parsedEntries ?? new List<PackageAssetEntry>();
            _activePackageFileName = Path.GetFileName(req.packagePath);

            lock (JobLock)
            {
                _currentJobState = "importing";
                if (Jobs.TryGetValue(req.jobId, out var st))
                {
                    st.state = "importing";
                    st.message = req.interactive ? "Unity 側のインポート確認ダイアログで操作してください" : "Unity にインポート中…";
                }
            }

            try
            {
                AssetDatabase.ImportPackage(req.packagePath, req.interactive);
                // If non-interactive completed synchronously before callback or did not trigger callback, hooks handle it
            }
            catch (Exception ex)
            {
                FinishActiveJob("failed", ex.Message, 0);
            }
        }

        private static void EnsureImportHooks()
        {
            if (_hooksRegistered) return;
            AssetDatabase.importPackageCompleted += OnImportCompleted;
            AssetDatabase.importPackageCancelled += OnImportCancelled;
            AssetDatabase.importPackageFailed += OnImportFailed;
            _hooksRegistered = true;
        }

        private static void OnImportCompleted(string packageName)
        {
            if (!_busy || string.IsNullOrEmpty(_activeJobId)) return;

            var rec = _activeRecord ?? new InstalledAssetRecord();
            rec.EnsureLists();
            rec.detectedBy = "import";
            if (rec.installedAt <= 0)
            {
                rec.installedAt = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            }

            var guids = new HashSet<string>(rec.guids, StringComparer.OrdinalIgnoreCase);
            var paths = new HashSet<string>(rec.assetPaths, StringComparer.OrdinalIgnoreCase);

            foreach (var entry in _activePackageEntries)
            {
                if (string.IsNullOrEmpty(entry.guid)) continue;
                string livePath = AssetDatabase.GUIDToAssetPath(entry.guid);
                if (!string.IsNullOrEmpty(livePath) && livePath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase))
                {
                    if (VamManifestStore.AssetExistsOnDisk(livePath))
                    {
                        guids.Add(entry.guid.ToLowerInvariant());
                        paths.Add(livePath);
                    }
                }
                else if (!string.IsNullOrEmpty(entry.assetPath) &&
                         entry.assetPath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase) &&
                         VamManifestStore.AssetExistsOnDisk(entry.assetPath))
                {
                    string g = AssetDatabase.AssetPathToGUID(entry.assetPath);
                    if (!string.IsNullOrEmpty(g)) guids.Add(g.ToLowerInvariant());
                    paths.Add(entry.assetPath);
                }
            }

            rec.guids = new List<string>(guids);
            rec.assetPaths = new List<string>(paths);

            var manifest = VamManifestStore.Load();
            VamManifestStore.Upsert(manifest, rec, preferExistingImport: false);
            VamManifestStore.Save(manifest);
            InstalledAssetsWindow.NotifyDataChanged();

            FinishActiveJob("completed", "インポートが完了しました", rec.assetPaths.Count);
        }

        private static void OnImportCancelled(string packageName)
        {
            if (!_busy || string.IsNullOrEmpty(_activeJobId)) return;
            FinishActiveJob("cancelled", "インポートがキャンセルされました", 0);
        }

        private static void OnImportFailed(string packageName, string errorMessage)
        {
            if (!_busy || string.IsNullOrEmpty(_activeJobId)) return;
            FinishActiveJob("failed", string.IsNullOrEmpty(errorMessage) ? "インポートに失敗しました" : errorMessage, 0);
        }

        private static void FinishActiveJob(string state, string message, int importedCount)
        {
            string jobId = _activeJobId;
            string cleanupDir = _activeCleanupDir;

            _activeJobId = "";
            _activeRecord = null;
            _activeCleanupDir = "";
            _activePackageEntries = new List<PackageAssetEntry>();
            _activePackageFileName = "";

            lock (JobLock)
            {
                _busy = false;
                _currentJobState = state;
                if (!string.IsNullOrEmpty(jobId))
                {
                    Jobs[jobId] = new ImportStatusResponse
                    {
                        jobId = jobId,
                        state = state,
                        message = message,
                        importedCount = importedCount
                    };
                }
            }

            SafeCleanupTempDir(cleanupDir);
        }

        private static void SafeCleanupTempDir(string cleanupDir)
        {
            if (string.IsNullOrEmpty(cleanupDir)) return;
            try
            {
                string vamTempBase = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "VRCAssetManager"));
                if (!vamTempBase.EndsWith(Path.DirectorySeparatorChar.ToString()))
                {
                    vamTempBase += Path.DirectorySeparatorChar;
                }
                string fullCleanup = Path.GetFullPath(cleanupDir);
                if (fullCleanup.StartsWith(vamTempBase, StringComparison.OrdinalIgnoreCase) && Directory.Exists(fullCleanup))
                {
                    Directory.Delete(fullCleanup, true);
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[VRC Asset Manager Bridge] Temp cleanup warning: {ex.Message}");
            }
        }

        private static void RegisterInstance()
        {
            if (!_running || _port <= 0) return;
            int myPid = Process.GetCurrentProcess().Id;
            long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            string projPath = VamManifestStore.ProjectRoot;
            string projName = Path.GetFileName(projPath.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));

            UpdateRegistry(reg =>
            {
                reg.instances.RemoveAll(x => x.pid == myPid || !IsProcessAlive(x.pid));
                reg.instances.Add(new UnityInstanceEntry
                {
                    pid = myPid,
                    projectPath = projPath,
                    projectName = projName,
                    unityVersion = Application.unityVersion,
                    port = _port,
                    token = _token,
                    bridgeVersion = BridgeVersion,
                    startedAt = _startedAt,
                    lastHeartbeat = now
                });
            });
        }

        private static void UnregisterInstance()
        {
            int myPid = Process.GetCurrentProcess().Id;
            UpdateRegistry(reg =>
            {
                reg.instances.RemoveAll(x => x.pid == myPid || !IsProcessAlive(x.pid));
            });
        }

        private static void UpdateRegistry(Action<UnityInstanceRegistry> mutator)
        {
            try
            {
                string path = RegistryPath;
                string dir = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }

                using (var mutex = new Mutex(false, @"Local\VRCAssetManager_UnityRegistry"))
                {
                    bool acquired = false;
                    try
                    {
                        acquired = mutex.WaitOne(1500);
                    }
                    catch (AbandonedMutexException)
                    {
                        acquired = true;
                    }

                    try
                    {
                        var reg = new UnityInstanceRegistry();
                        if (File.Exists(path))
                        {
                            try
                            {
                                string raw = File.ReadAllText(path, Utf8NoBom);
                                var parsed = JsonUtility.FromJson<UnityInstanceRegistry>(raw);
                                if (parsed != null) reg = parsed;
                            }
                            catch
                            {
                                reg = new UnityInstanceRegistry();
                            }
                        }
                        reg.EnsureLists();
                        mutator(reg);
                        string tmp = path + ".tmp." + Process.GetCurrentProcess().Id;
                        File.WriteAllText(tmp, JsonUtility.ToJson(reg, true), Utf8NoBom);
                        if (File.Exists(path))
                        {
                            File.Replace(tmp, path, null);
                        }
                        else
                        {
                            File.Move(tmp, path);
                        }
                    }
                    finally
                    {
                        if (acquired) mutex.ReleaseMutex();
                    }
                }
            }
            catch
            {
                // Non-fatal if another process briefly locks file
            }
        }

        private static bool IsProcessAlive(int pid)
        {
            if (pid <= 0) return false;
            try
            {
                var p = Process.GetProcessById(pid);
                return !p.HasExited;
            }
            catch
            {
                return false;
            }
        }

        private static T RunOnMainThread<T>(Func<T> func)
        {
            using (var done = new ManualResetEventSlim(false))
            {
                T result = default;
                Exception error = null;
                MainThreadQueue.Enqueue(() =>
                {
                    try
                    {
                        result = func();
                    }
                    catch (Exception ex)
                    {
                        error = ex;
                    }
                    finally
                    {
                        done.Set();
                    }
                });

                if (!done.Wait(5000))
                {
                    throw new TimeoutException("Unity main thread timed out");
                }
                if (error != null) throw error;
                return result;
            }
        }

        private static string ReadBody(HttpListenerRequest req)
        {
            if (!req.HasEntityBody) return "";
            using (var sr = new StreamReader(req.InputStream, Utf8NoBom))
            {
                return sr.ReadToEnd();
            }
        }

        private static void WriteJson(HttpListenerResponse resp, int statusCode, object payload)
        {
            byte[] data = Utf8NoBom.GetBytes(JsonUtility.ToJson(payload));
            resp.StatusCode = statusCode;
            resp.ContentType = "application/json; charset=utf-8";
            resp.ContentLength64 = data.Length;
            using (var os = resp.OutputStream)
            {
                os.Write(data, 0, data.Length);
            }
        }

        private static bool ConstantTimeEquals(string a, string b)
        {
            if (a == null || b == null || a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++)
            {
                diff |= a[i] ^ b[i];
            }
            return diff == 0;
        }
    }
}
