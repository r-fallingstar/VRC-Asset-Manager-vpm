using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace VrcAssetManager.Bridge
{
    public static class VamManifestStore
    {
        private static readonly UTF8Encoding Utf8NoBom = new UTF8Encoding(false);
        private static readonly string[] ScanExtensions = { ".unity", ".prefab", ".mat", ".controller", ".anim", ".asset", ".overridecontroller" };

        public static string ProjectRoot
        {
            get
            {
                string dir = Path.GetDirectoryName(Application.dataPath);
                return string.IsNullOrEmpty(dir) ? Directory.GetCurrentDirectory() : dir;
            }
        }

        public static string ManifestPath => Path.Combine(ProjectRoot, "ProjectSettings", "VRCAssetManagerInstalled.json");

        public static InstalledManifest Load()
        {
            var manifest = new InstalledManifest
            {
                schemaVersion = 1,
                projectName = Path.GetFileName(ProjectRoot.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)),
                projectPath = ProjectRoot
            };

            string path = ManifestPath;
            if (!File.Exists(path))
            {
                return manifest;
            }

            try
            {
                string json = File.ReadAllText(path, Utf8NoBom);
                if (!string.IsNullOrWhiteSpace(json))
                {
                    var parsed = JsonUtility.FromJson<InstalledManifest>(json);
                    if (parsed != null)
                    {
                        parsed.EnsureLists();
                        if (string.IsNullOrEmpty(parsed.projectName)) parsed.projectName = manifest.projectName;
                        if (string.IsNullOrEmpty(parsed.projectPath)) parsed.projectPath = ProjectRoot;
                        return parsed;
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[VRC Asset Manager Bridge] Failed to load manifest: {ex.Message}");
            }

            return manifest;
        }

        public static void Save(InstalledManifest manifest)
        {
            if (manifest == null) return;
            manifest.EnsureLists();
            manifest.schemaVersion = 1;
            manifest.projectName = Path.GetFileName(ProjectRoot.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
            manifest.projectPath = ProjectRoot;
            manifest.updatedAt = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

            string dir = Path.GetDirectoryName(ManifestPath);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }

            string tmp = ManifestPath + ".tmp";
            string json = JsonUtility.ToJson(manifest, true);
            File.WriteAllText(tmp, json, Utf8NoBom);
            if (File.Exists(ManifestPath))
            {
                File.Replace(tmp, ManifestPath, null);
            }
            else
            {
                File.Move(tmp, ManifestPath);
            }
        }

        public static void Upsert(InstalledManifest manifest, InstalledAssetRecord incoming, bool preferExistingImport)
        {
            if (manifest == null || incoming == null) return;
            manifest.EnsureLists();
            incoming.EnsureLists();

            InstalledAssetRecord existing = null;
            foreach (var item in manifest.assets)
            {
                if (!string.IsNullOrEmpty(incoming.itemId) && string.Equals(item.itemId, incoming.itemId, StringComparison.OrdinalIgnoreCase))
                {
                    existing = item;
                    break;
                }
                if (!string.IsNullOrEmpty(incoming.boothId) && string.Equals(item.boothId, incoming.boothId, StringComparison.OrdinalIgnoreCase))
                {
                    existing = item;
                    break;
                }
            }

            if (existing == null)
            {
                if (incoming.installedAt <= 0)
                {
                    incoming.installedAt = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                }
                manifest.assets.Add(incoming);
                return;
            }

            existing.EnsureLists();
            bool keepImportType = preferExistingImport && existing.detectedBy == "import" && incoming.detectedBy == "scan";

            if (!keepImportType)
            {
                existing.detectedBy = string.IsNullOrEmpty(incoming.detectedBy) ? existing.detectedBy : incoming.detectedBy;
                if (incoming.installedAt > 0) existing.installedAt = incoming.installedAt;
            }

            if (!string.IsNullOrEmpty(incoming.itemId)) existing.itemId = incoming.itemId;
            if (!string.IsNullOrEmpty(incoming.boothId)) existing.boothId = incoming.boothId;
            if (!string.IsNullOrEmpty(incoming.title)) existing.title = incoming.title;
            if (!string.IsNullOrEmpty(incoming.shop)) existing.shop = incoming.shop;
            if (!string.IsNullOrEmpty(incoming.category)) existing.category = incoming.category;
            if (!string.IsNullOrEmpty(incoming.categoryLabel)) existing.categoryLabel = incoming.categoryLabel;
            if (!string.IsNullOrEmpty(incoming.subcategory)) existing.subcategory = incoming.subcategory;
            if (!string.IsNullOrEmpty(incoming.boothUrl)) existing.boothUrl = incoming.boothUrl;
            if (!string.IsNullOrEmpty(incoming.memo)) existing.memo = incoming.memo;
            if (incoming.tags.Count > 0) existing.tags = new List<string>(incoming.tags);
            if (!string.IsNullOrEmpty(incoming.version)) existing.version = incoming.version;
            if (!string.IsNullOrEmpty(incoming.sourcePath)) existing.sourcePath = incoming.sourcePath;
            if (!string.IsNullOrEmpty(incoming.sourceFile)) existing.sourceFile = incoming.sourceFile;
            if (!string.IsNullOrEmpty(incoming.thumbPath)) existing.thumbPath = incoming.thumbPath;

            var guidSet = new HashSet<string>(existing.guids, StringComparer.OrdinalIgnoreCase);
            foreach (var g in incoming.guids)
            {
                if (!string.IsNullOrEmpty(g) && guidSet.Add(g.ToLowerInvariant()))
                {
                    existing.guids.Add(g.ToLowerInvariant());
                }
            }

            var pathSet = new HashSet<string>(existing.assetPaths, StringComparer.OrdinalIgnoreCase);
            foreach (var p in incoming.assetPaths)
            {
                if (!string.IsNullOrEmpty(p) && pathSet.Add(p))
                {
                    existing.assetPaths.Add(p);
                }
            }
        }

        public static List<string> ResolveLivePaths(InstalledAssetRecord rec)
        {
            var results = new List<string>();
            if (rec == null) return results;
            rec.EnsureLists();

            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var g in rec.guids)
            {
                if (string.IsNullOrEmpty(g)) continue;
                string p = AssetDatabase.GUIDToAssetPath(g);
                if (!string.IsNullOrEmpty(p) && p.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase) && AssetExistsOnDisk(p))
                {
                    if (seen.Add(p)) results.Add(p);
                }
            }

            foreach (var raw in rec.assetPaths)
            {
                if (string.IsNullOrEmpty(raw)) continue;
                string p = raw.Replace('\\', '/');
                if (p.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase) && AssetExistsOnDisk(p))
                {
                    if (seen.Add(p)) results.Add(p);
                }
            }

            results.Sort(StringComparer.OrdinalIgnoreCase);
            return results;
        }

        public static bool AssetExistsOnDisk(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath)) return false;
            if (AssetDatabase.IsValidFolder(assetPath)) return true;
            string full = Path.Combine(ProjectRoot, assetPath.Replace('/', Path.DirectorySeparatorChar));
            return File.Exists(full);
        }

        public static UninstallAnalysis AnalyzeUninstall(InstalledManifest manifest, InstalledAssetRecord target)
        {
            var analysis = new UninstallAnalysis();
            if (target == null) return analysis;
            manifest?.EnsureLists();
            target.EnsureLists();

            var otherGuids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var otherPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (manifest != null)
            {
                foreach (var item in manifest.assets)
                {
                    if (item == null || item == target) continue;
                    if (!string.IsNullOrEmpty(target.itemId) && string.Equals(item.itemId, target.itemId, StringComparison.OrdinalIgnoreCase)) continue;
                    item.EnsureLists();
                    foreach (var g in item.guids) otherGuids.Add(g);
                    foreach (var p in ResolveLivePaths(item)) otherPaths.Add(p);
                }
            }

            var livePaths = ResolveLivePaths(target);
            var targetFileGuids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var targetOwnedPathSet = new HashSet<string>(livePaths, StringComparer.OrdinalIgnoreCase);

            foreach (var p in livePaths)
            {
                string guid = AssetDatabase.AssetPathToGUID(p);
                bool shared = (!string.IsNullOrEmpty(guid) && otherGuids.Contains(guid)) || otherPaths.Contains(p);

                if (AssetDatabase.IsValidFolder(p))
                {
                    if (!shared) analysis.exclusiveFolderPaths.Add(p);
                    else analysis.sharedPaths.Add(p);
                }
                else
                {
                    if (!shared)
                    {
                        analysis.exclusiveFilePaths.Add(p);
                        if (!string.IsNullOrEmpty(guid)) targetFileGuids.Add(guid);
                    }
                    else
                    {
                        analysis.sharedPaths.Add(p);
                    }
                }
            }

            // Scan external scenes/prefabs/materials/controllers for references to exclusive GUIDs
            if (targetFileGuids.Count > 0)
            {
                string assetsDir = Path.Combine(ProjectRoot, "Assets");
                if (Directory.Exists(assetsDir))
                {
                    var guidList = targetFileGuids.ToList();
                    foreach (var fullFile in Directory.EnumerateFiles(assetsDir, "*.*", SearchOption.AllDirectories))
                    {
                        string ext = Path.GetExtension(fullFile).ToLowerInvariant();
                        if (!ScanExtensions.Contains(ext)) continue;

                        string rel = "Assets/" + fullFile.Substring(assetsDir.Length + 1).Replace('\\', '/');
                        if (targetOwnedPathSet.Contains(rel)) continue;

                        try
                        {
                            string content = File.ReadAllText(fullFile);
                            bool matched = false;
                            for (int i = 0; i < guidList.Count; i++)
                            {
                                if (content.IndexOf(guidList[i], StringComparison.OrdinalIgnoreCase) >= 0)
                                {
                                    matched = true;
                                    break;
                                }
                            }
                            if (matched)
                            {
                                analysis.referencedByPaths.Add(rel);
                                if (analysis.referencedByPaths.Count >= 30) break;
                            }
                        }
                        catch
                        {
                            // Ignore unreadable files
                        }
                    }
                }
            }

            return analysis;
        }

        public static (int removedCount, List<string> failedPaths) ExecuteUninstall(
            InstalledManifest manifest,
            InstalledAssetRecord target,
            UninstallAnalysis analysis)
        {
            var failed = new List<string>();
            int removed = 0;

            if (analysis.exclusiveFilePaths.Count > 0)
            {
                AssetDatabase.MoveAssetsToTrash(analysis.exclusiveFilePaths.ToArray(), failed);
                removed = analysis.exclusiveFilePaths.Count - failed.Count;
            }

            // Clean up now-empty exclusive folders deepest-first
            var folders = analysis.exclusiveFolderPaths
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderByDescending(p => p.Length)
                .ToList();

            foreach (var folder in folders)
            {
                if (!AssetDatabase.IsValidFolder(folder)) continue;
                string fullDir = Path.Combine(ProjectRoot, folder.Replace('/', Path.DirectorySeparatorChar));
                if (!Directory.Exists(fullDir)) continue;

                bool hasRealContent = Directory.EnumerateFileSystemEntries(fullDir)
                    .Any(entry => !entry.EndsWith(".meta", StringComparison.OrdinalIgnoreCase));
                if (!hasRealContent)
                {
                    var fFailed = new List<string>();
                    AssetDatabase.MoveAssetsToTrash(new[] { folder }, fFailed);
                }
            }

            if (manifest != null && target != null)
            {
                manifest.assets.RemoveAll(a =>
                    a == target ||
                    (!string.IsNullOrEmpty(target.itemId) && string.Equals(a.itemId, target.itemId, StringComparison.OrdinalIgnoreCase)));
                Save(manifest);
            }

            AssetDatabase.Refresh();
            return (removed, failed);
        }
    }
}
