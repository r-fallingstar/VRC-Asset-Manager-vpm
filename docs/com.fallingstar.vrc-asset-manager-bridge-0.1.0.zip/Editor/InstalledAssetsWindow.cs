using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace VrcAssetManager.Bridge
{
    public class InstalledAssetsWindow : EditorWindow
    {
        private static event Action DataChanged;

        private InstalledManifest _manifest = new InstalledManifest();
        private readonly Dictionary<string, Texture2D> _thumbCache = new Dictionary<string, Texture2D>(StringComparer.OrdinalIgnoreCase);

        private string _searchQuery = "";
        private string _selectedCategory = "すべて";
        private string _sortMode = "recent";
        private string _selectedItemId = "";
        private string _assetFilter = "all";
        private string _pendingSelectItemId = "";
        private string _pendingSelectBoothId = "";

        private VisualElement _gridContainer;
        private VisualElement _detailPane;
        private ScrollView _detailScroll;
        private Label _countLabel;
        private Label _bridgeLabel;
        private VisualElement _bridgeDot;
        private DropdownField _catDropdown;
        private TextField _searchField;

        [MenuItem("Tools/VRC Asset Manager/導入済みアセット", false, 100)]
        [MenuItem("Window/VRC Asset Manager/導入済みアセット", false, 2000)]
        public static void OpenWindow()
        {
            OpenAndSelect(null, null);
        }

        public static void OpenAndSelect(string itemId, string boothId)
        {
            var projectType = typeof(Editor).Assembly.GetType("UnityEditor.ProjectBrowser");
            var consoleType = typeof(Editor).Assembly.GetType("UnityEditor.ConsoleWindow");
            var dockTypes = new[] { projectType, consoleType }.Where(t => t != null).ToArray();

            var win = dockTypes.Length > 0
                ? GetWindow<InstalledAssetsWindow>("導入済みアセット", true, dockTypes)
                : GetWindow<InstalledAssetsWindow>("導入済みアセット", true);

            win.minSize = new Vector2(460, 280);
            if (!string.IsNullOrEmpty(itemId) || !string.IsNullOrEmpty(boothId))
            {
                win._pendingSelectItemId = itemId ?? "";
                win._pendingSelectBoothId = boothId ?? "";
                win.ApplyPendingSelection();
            }
            win.Show();
            win.Focus();
        }

        public static void NotifyDataChanged()
        {
            DataChanged?.Invoke();
        }

        private void OnEnable()
        {
            DataChanged += OnExternalDataChanged;
            BuildUI();
            ReloadManifest();
        }

        private void OnDisable()
        {
            DataChanged -= OnExternalDataChanged;
            ClearThumbCache();
        }

        private void OnExternalDataChanged()
        {
            ReloadManifest();
        }

        private void ClearThumbCache()
        {
            foreach (var tex in _thumbCache.Values)
            {
                if (tex != null) DestroyImmediate(tex);
            }
            _thumbCache.Clear();
        }

        private bool IsDark => EditorGUIUtility.isProSkin;
        private Color BgColor => IsDark ? new Color(0.16f, 0.17f, 0.19f) : new Color(0.95f, 0.96f, 0.98f);
        private Color SurfaceColor => IsDark ? new Color(0.21f, 0.22f, 0.25f) : Color.white;
        private Color Surface2Color => IsDark ? new Color(0.18f, 0.19f, 0.22f) : new Color(0.97f, 0.98f, 0.99f);
        private Color BorderColor => IsDark ? new Color(0.29f, 0.31f, 0.35f) : new Color(0.84f, 0.87f, 0.91f);
        private Color TextColor => IsDark ? new Color(0.93f, 0.94f, 0.96f) : new Color(0.12f, 0.14f, 0.18f);
        private Color MutedColor => IsDark ? new Color(0.66f, 0.69f, 0.75f) : new Color(0.45f, 0.49f, 0.56f);
        private static readonly Color AccentColor = new Color(0.99f, 0.30f, 0.31f);

        private void BuildUI()
        {
            rootVisualElement.Clear();
            rootVisualElement.style.flexGrow = 1;
            rootVisualElement.style.backgroundColor = BgColor;
            rootVisualElement.style.color = TextColor;

            // Top Toolbar
            var topBar = new VisualElement();
            topBar.style.flexDirection = FlexDirection.Row;
            topBar.style.alignItems = Align.Center;
            topBar.style.flexWrap = Wrap.Wrap;
            topBar.style.paddingLeft = 10;
            topBar.style.paddingRight = 10;
            topBar.style.paddingTop = 6;
            topBar.style.paddingBottom = 6;
            topBar.style.backgroundColor = SurfaceColor;
            topBar.style.borderBottomWidth = 1;
            topBar.style.borderBottomColor = BorderColor;

            var titleLbl = new Label("導入済みアセット");
            titleLbl.style.fontSize = 14;
            titleLbl.style.unityFontStyleAndWeight = FontStyle.Bold;
            titleLbl.style.marginRight = 8;
            topBar.Add(titleLbl);

            _countLabel = new Label("0 件");
            _countLabel.style.fontSize = 11;
            _countLabel.style.color = MutedColor;
            _countLabel.style.marginRight = 12;
            topBar.Add(_countLabel);

            _searchField = new TextField();
            _searchField.value = _searchQuery;
            _searchField.style.width = 190;
            _searchField.style.marginRight = 6;
            _searchField.tooltip = "商品名・ショップ名・メモで検索";
            _searchField.RegisterValueChangedCallback(evt =>
            {
                _searchQuery = evt.newValue ?? "";
                RenderGrid();
            });
            topBar.Add(_searchField);

            _catDropdown = new DropdownField(new List<string> { "すべて" }, 0);
            _catDropdown.style.width = 120;
            _catDropdown.style.marginRight = 6;
            _catDropdown.RegisterValueChangedCallback(evt =>
            {
                _selectedCategory = evt.newValue ?? "すべて";
                RenderGrid();
            });
            topBar.Add(_catDropdown);

            var sortChoices = new List<string> { "導入日時順", "名前順", "ショップ順" };
            var sortDropdown = new DropdownField(sortChoices, 0);
            sortDropdown.style.width = 105;
            sortDropdown.style.marginRight = 6;
            sortDropdown.RegisterValueChangedCallback(evt =>
            {
                if (evt.newValue == "名前順") _sortMode = "name";
                else if (evt.newValue == "ショップ順") _sortMode = "shop";
                else _sortMode = "recent";
                RenderGrid();
            });
            topBar.Add(sortDropdown);

            var reloadBtn = new Button(ReloadManifest) { text = "再読込" };
            reloadBtn.style.marginRight = 8;
            topBar.Add(reloadBtn);

            var spacer = new VisualElement();
            spacer.style.flexGrow = 1;
            topBar.Add(spacer);

            var statusBox = new VisualElement();
            statusBox.style.flexDirection = FlexDirection.Row;
            statusBox.style.alignItems = Align.Center;
            _bridgeDot = new VisualElement();
            _bridgeDot.style.width = 8;
            _bridgeDot.style.height = 8;
            _bridgeDot.style.borderTopLeftRadius = 4;
            _bridgeDot.style.borderTopRightRadius = 4;
            _bridgeDot.style.borderBottomLeftRadius = 4;
            _bridgeDot.style.borderBottomRightRadius = 4;
            _bridgeDot.style.marginRight = 5;
            statusBox.Add(_bridgeDot);

            _bridgeLabel = new Label();
            _bridgeLabel.style.fontSize = 11;
            _bridgeLabel.style.color = MutedColor;
            statusBox.Add(_bridgeLabel);
            topBar.Add(statusBox);

            rootVisualElement.Add(topBar);

            // Body Split
            var body = new VisualElement();
            body.style.flexDirection = FlexDirection.Row;
            body.style.flexGrow = 1;
            body.style.minHeight = 0;

            var gridScroll = new ScrollView(ScrollViewMode.Vertical);
            gridScroll.style.flexGrow = 1;
            gridScroll.style.flexBasis = 0;
            gridScroll.style.paddingLeft = 10;
            gridScroll.style.paddingRight = 10;
            gridScroll.style.paddingTop = 10;
            gridScroll.style.paddingBottom = 10;

            _gridContainer = new VisualElement();
            _gridContainer.style.flexDirection = FlexDirection.Row;
            _gridContainer.style.flexWrap = Wrap.Wrap;
            _gridContainer.style.alignItems = Align.FlexStart;
            gridScroll.Add(_gridContainer);
            body.Add(gridScroll);

            _detailPane = new VisualElement();
            _detailPane.style.width = 350;
            _detailPane.style.minWidth = 310;
            _detailPane.style.backgroundColor = SurfaceColor;
            _detailPane.style.borderLeftWidth = 1;
            _detailPane.style.borderLeftColor = BorderColor;
            _detailPane.style.display = DisplayStyle.None;

            _detailScroll = new ScrollView(ScrollViewMode.Vertical);
            _detailScroll.style.flexGrow = 1;
            _detailScroll.style.paddingLeft = 12;
            _detailScroll.style.paddingRight = 12;
            _detailScroll.style.paddingTop = 10;
            _detailScroll.style.paddingBottom = 14;
            _detailPane.Add(_detailScroll);
            body.Add(_detailPane);

            rootVisualElement.Add(body);
            UpdateBridgeStatus();
        }

        private void UpdateBridgeStatus()
        {
            if (_bridgeDot == null || _bridgeLabel == null) return;
            if (VamBridgeServer.IsRunning)
            {
                _bridgeDot.style.backgroundColor = new Color(0.13f, 0.77f, 0.37f);
                _bridgeLabel.text = $"連携待機中 (:{VamBridgeServer.Port})";
            }
            else
            {
                _bridgeDot.style.backgroundColor = new Color(0.64f, 0.66f, 0.70f);
                _bridgeLabel.text = "オフライン";
            }
        }

        private void ReloadManifest()
        {
            _manifest = VamManifestStore.Load();
            UpdateBridgeStatus();
            RefreshCategories();
            ApplyPendingSelection();
            RenderGrid();
            RenderDetail();
        }

        private void ApplyPendingSelection()
        {
            if (_manifest?.assets == null) return;
            if (string.IsNullOrEmpty(_pendingSelectItemId) && string.IsNullOrEmpty(_pendingSelectBoothId)) return;

            var hit = _manifest.assets.FirstOrDefault(a =>
                (!string.IsNullOrEmpty(_pendingSelectItemId) && string.Equals(a.itemId, _pendingSelectItemId, StringComparison.OrdinalIgnoreCase)) ||
                (!string.IsNullOrEmpty(_pendingSelectBoothId) && string.Equals(a.boothId, _pendingSelectBoothId, StringComparison.OrdinalIgnoreCase)));

            if (hit != null)
            {
                _selectedItemId = hit.itemId;
                _pendingSelectItemId = "";
                _pendingSelectBoothId = "";
            }
        }

        private void RefreshCategories()
        {
            if (_catDropdown == null) return;
            var cats = new List<string> { "すべて" };
            var distinct = _manifest.assets
                .Select(a => string.IsNullOrEmpty(a.categoryLabel) ? a.category : a.categoryLabel)
                .Where(c => !string.IsNullOrWhiteSpace(c))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(c => c, StringComparer.CurrentCultureIgnoreCase);
            cats.AddRange(distinct);
            _catDropdown.choices = cats;
            if (!cats.Contains(_selectedCategory))
            {
                _selectedCategory = "すべて";
            }
            _catDropdown.SetValueWithoutNotify(_selectedCategory);
        }

        private List<InstalledAssetRecord> GetFilteredAssets()
        {
            IEnumerable<InstalledAssetRecord> q = _manifest.assets ?? new List<InstalledAssetRecord>();

            if (!string.IsNullOrEmpty(_selectedCategory) && _selectedCategory != "すべて")
            {
                q = q.Where(a =>
                {
                    string c = string.IsNullOrEmpty(a.categoryLabel) ? a.category : a.categoryLabel;
                    return string.Equals(c, _selectedCategory, StringComparison.OrdinalIgnoreCase);
                });
            }

            if (!string.IsNullOrWhiteSpace(_searchQuery))
            {
                string kw = _searchQuery.Trim().ToLowerInvariant();
                q = q.Where(a =>
                    (a.title ?? "").ToLowerInvariant().Contains(kw) ||
                    (a.shop ?? "").ToLowerInvariant().Contains(kw) ||
                    (a.memo ?? "").ToLowerInvariant().Contains(kw) ||
                    (a.tags != null && a.tags.Any(t => (t ?? "").ToLowerInvariant().Contains(kw))));
            }

            switch (_sortMode)
            {
                case "name":
                    q = q.OrderBy(a => a.title, StringComparer.CurrentCultureIgnoreCase);
                    break;
                case "shop":
                    q = q.OrderBy(a => a.shop, StringComparer.CurrentCultureIgnoreCase)
                         .ThenBy(a => a.title, StringComparer.CurrentCultureIgnoreCase);
                    break;
                default:
                    q = q.OrderByDescending(a => a.installedAt)
                         .ThenBy(a => a.title, StringComparer.CurrentCultureIgnoreCase);
                    break;
            }

            return q.ToList();
        }

        private void RenderGrid()
        {
            if (_gridContainer == null) return;
            _gridContainer.Clear();

            var items = GetFilteredAssets();
            _countLabel.text = $"{items.Count} / {_manifest.assets.Count} 件";

            if (items.Count == 0)
            {
                var emptyBox = new VisualElement();
                emptyBox.style.flexGrow = 1;
                emptyBox.style.paddingTop = 48;
                emptyBox.style.alignItems = Align.Center;

                string msg = _manifest.assets.Count == 0
                    ? "このプロジェクトにはまだ導入済みアセットが記録されていません。\n\nVRC Asset Manager から「Unityにインポート」または\n設定の「既存アセットを検出」を実行してください。"
                    : "検索条件に一致するアセットがありません。";
                var emptyLbl = new Label(msg);
                emptyLbl.style.unityTextAlign = TextAnchor.MiddleCenter;
                emptyLbl.style.color = MutedColor;
                emptyLbl.style.whiteSpace = WhiteSpace.Normal;
                emptyBox.Add(emptyLbl);
                _gridContainer.Add(emptyBox);
                return;
            }

            foreach (var rec in items)
            {
                _gridContainer.Add(CreateCard(rec));
            }
        }

        private VisualElement CreateCard(InstalledAssetRecord rec)
        {
            bool selected = !string.IsNullOrEmpty(_selectedItemId) &&
                            string.Equals(rec.itemId, _selectedItemId, StringComparison.OrdinalIgnoreCase);

            var card = new VisualElement();
            card.style.width = 166;
            card.style.marginRight = 8;
            card.style.marginBottom = 8;
            card.style.paddingTop = 6;
            card.style.paddingBottom = 8;
            card.style.paddingLeft = 6;
            card.style.paddingRight = 6;
            card.style.backgroundColor = SurfaceColor;
            card.style.borderTopWidth = 1;
            card.style.borderRightWidth = 1;
            card.style.borderBottomWidth = 1;
            card.style.borderLeftWidth = 1;
            var bc = selected ? AccentColor : BorderColor;
            card.style.borderTopColor = bc;
            card.style.borderRightColor = bc;
            card.style.borderBottomColor = bc;
            card.style.borderLeftColor = bc;
            card.style.borderTopLeftRadius = 8;
            card.style.borderTopRightRadius = 8;
            card.style.borderBottomLeftRadius = 8;
            card.style.borderBottomRightRadius = 8;

            var imgWrap = new VisualElement();
            imgWrap.style.height = 112;
            imgWrap.style.backgroundColor = Surface2Color;
            imgWrap.style.borderTopLeftRadius = 6;
            imgWrap.style.borderTopRightRadius = 6;
            imgWrap.style.borderBottomLeftRadius = 6;
            imgWrap.style.borderBottomRightRadius = 6;
            imgWrap.style.marginBottom = 6;
            imgWrap.style.overflow = Overflow.Hidden;
            imgWrap.style.justifyContent = Justify.Center;
            imgWrap.style.alignItems = Align.Center;

            var tex = LoadThumbnail(rec.thumbPath);
            if (tex != null)
            {
                var img = new Image { image = tex, scaleMode = ScaleMode.ScaleAndCrop };
                img.style.width = Length.Percent(100);
                img.style.height = Length.Percent(100);
                imgWrap.Add(img);
            }
            else
            {
                var ph = new Label(string.IsNullOrEmpty(rec.title) ? "Asset" : rec.title.Substring(0, Math.Min(12, rec.title.Length)));
                ph.style.fontSize = 11;
                ph.style.color = MutedColor;
                ph.style.unityTextAlign = TextAnchor.MiddleCenter;
                ph.style.whiteSpace = WhiteSpace.Normal;
                imgWrap.Add(ph);
            }

            if (rec.detectedBy == "scan")
            {
                var badge = new Label("自動検出");
                badge.style.position = Position.Absolute;
                badge.style.top = 4;
                badge.style.left = 4;
                badge.style.fontSize = 9;
                badge.style.color = Color.white;
                badge.style.backgroundColor = new Color(0.15f, 0.45f, 0.85f, 0.9f);
                badge.style.paddingLeft = 5;
                badge.style.paddingRight = 5;
                badge.style.paddingTop = 1;
                badge.style.paddingBottom = 1;
                badge.style.borderTopLeftRadius = 4;
                badge.style.borderTopRightRadius = 4;
                badge.style.borderBottomLeftRadius = 4;
                badge.style.borderBottomRightRadius = 4;
                imgWrap.Add(badge);
            }

            card.Add(imgWrap);

            string catText = string.IsNullOrEmpty(rec.categoryLabel) ? rec.category : rec.categoryLabel;
            if (!string.IsNullOrEmpty(catText))
            {
                var catLbl = new Label(catText);
                catLbl.style.fontSize = 10;
                catLbl.style.color = AccentColor;
                catLbl.style.marginBottom = 2;
                card.Add(catLbl);
            }

            var titleLbl = new Label(string.IsNullOrEmpty(rec.title) ? "(名称未設定)" : rec.title);
            titleLbl.style.fontSize = 12;
            titleLbl.style.unityFontStyleAndWeight = FontStyle.Bold;
            titleLbl.style.whiteSpace = WhiteSpace.Normal;
            titleLbl.style.maxHeight = 34;
            titleLbl.style.overflow = Overflow.Hidden;
            titleLbl.style.marginBottom = 3;
            card.Add(titleLbl);

            string sub = string.IsNullOrEmpty(rec.shop) ? "-" : rec.shop;
            if (!string.IsNullOrEmpty(rec.version))
            {
                sub += $" · {rec.version}";
            }
            var shopLbl = new Label(sub);
            shopLbl.style.fontSize = 10;
            shopLbl.style.color = MutedColor;
            shopLbl.style.overflow = Overflow.Hidden;
            shopLbl.style.textOverflow = TextOverflow.Ellipsis;
            card.Add(shopLbl);

            card.RegisterCallback<MouseDownEvent>(evt =>
            {
                if (evt.button != 0) return;
                _selectedItemId = rec.itemId;
                RenderGrid();
                RenderDetail();
            });

            return card;
        }

        private void RenderDetail()
        {
            if (_detailPane == null || _detailScroll == null) return;
            var rec = _manifest.assets.FirstOrDefault(a =>
                !string.IsNullOrEmpty(_selectedItemId) &&
                string.Equals(a.itemId, _selectedItemId, StringComparison.OrdinalIgnoreCase));

            if (rec == null)
            {
                _detailPane.style.display = DisplayStyle.None;
                return;
            }

            _detailPane.style.display = DisplayStyle.Flex;
            _detailScroll.Clear();

            // Header + Close
            var headRow = new VisualElement();
            headRow.style.flexDirection = FlexDirection.Row;
            headRow.style.alignItems = Align.Center;
            headRow.style.marginBottom = 8;

            string cat = string.IsNullOrEmpty(rec.categoryLabel) ? rec.category : rec.categoryLabel;
            var catBadge = new Label(string.IsNullOrEmpty(cat) ? "アセット" : cat);
            catBadge.style.fontSize = 11;
            catBadge.style.color = AccentColor;
            catBadge.style.unityFontStyleAndWeight = FontStyle.Bold;
            catBadge.style.flexGrow = 1;
            headRow.Add(catBadge);

            var closeBtn = new Button(() =>
            {
                _selectedItemId = "";
                RenderGrid();
                RenderDetail();
            }) { text = "×" };
            closeBtn.style.width = 24;
            headRow.Add(closeBtn);
            _detailScroll.Add(headRow);

            // Large thumb
            var tex = LoadThumbnail(rec.thumbPath);
            if (tex != null)
            {
                var img = new Image { image = tex, scaleMode = ScaleMode.ScaleToFit };
                img.style.height = 170;
                img.style.marginBottom = 8;
                img.style.backgroundColor = Surface2Color;
                img.style.borderTopLeftRadius = 6;
                img.style.borderTopRightRadius = 6;
                img.style.borderBottomLeftRadius = 6;
                img.style.borderBottomRightRadius = 6;
                _detailScroll.Add(img);
            }

            var titleLbl = new Label(rec.title);
            titleLbl.style.fontSize = 14;
            titleLbl.style.unityFontStyleAndWeight = FontStyle.Bold;
            titleLbl.style.whiteSpace = WhiteSpace.Normal;
            titleLbl.style.marginBottom = 4;
            _detailScroll.Add(titleLbl);

            string metaText = $"ショップ: {(string.IsNullOrEmpty(rec.shop) ? "-" : rec.shop)}";
            if (!string.IsNullOrEmpty(rec.version)) metaText += $"  |  Ver: {rec.version}";
            if (rec.installedAt > 0)
            {
                var dt = DateTimeOffset.FromUnixTimeSeconds(rec.installedAt).LocalDateTime;
                metaText += $"\n導入日時: {dt:yyyy/MM/dd HH:mm}（{(rec.detectedBy == "scan" ? "自動検出" : "インポート")}）";
            }
            var metaLbl = new Label(metaText);
            metaLbl.style.fontSize = 11;
            metaLbl.style.color = MutedColor;
            metaLbl.style.whiteSpace = WhiteSpace.Normal;
            metaLbl.style.marginBottom = 8;
            _detailScroll.Add(metaLbl);

            // Action Buttons
            var actRow = new VisualElement();
            actRow.style.flexDirection = FlexDirection.Row;
            actRow.style.flexWrap = Wrap.Wrap;
            actRow.style.marginBottom = 8;

            if (!string.IsNullOrEmpty(rec.boothUrl) &&
                (rec.boothUrl.StartsWith("https://", StringComparison.OrdinalIgnoreCase) ||
                 rec.boothUrl.StartsWith("http://", StringComparison.OrdinalIgnoreCase)))
            {
                var boothBtn = new Button(() => Application.OpenURL(rec.boothUrl)) { text = "BOOTHを開く" };
                boothBtn.style.marginRight = 4;
                boothBtn.style.marginBottom = 4;
                actRow.Add(boothBtn);
            }

            if (!string.IsNullOrEmpty(rec.sourcePath) && (Directory.Exists(rec.sourcePath) || File.Exists(rec.sourcePath)))
            {
                var dirBtn = new Button(() => EditorUtility.RevealInFinder(rec.sourcePath)) { text = "元フォルダを開く" };
                dirBtn.style.marginRight = 4;
                dirBtn.style.marginBottom = 4;
                actRow.Add(dirBtn);
            }

            if (!string.IsNullOrWhiteSpace(rec.memo))
            {
                var copyBtn = new Button(() =>
                {
                    EditorGUIUtility.systemCopyBuffer = rec.memo;
                    ShowNotification(new GUIContent("メモをコピーしました"));
                }) { text = "メモをコピー" };
                copyBtn.style.marginRight = 4;
                copyBtn.style.marginBottom = 4;
                actRow.Add(copyBtn);
            }

            var uninstBtn = new Button(() => ConfirmAndUninstall(rec)) { text = "アンインストール…" };
            uninstBtn.style.color = new Color(0.95f, 0.35f, 0.35f);
            uninstBtn.style.marginBottom = 4;
            actRow.Add(uninstBtn);
            _detailScroll.Add(actRow);

            // Memo
            if (!string.IsNullOrWhiteSpace(rec.memo))
            {
                var memoTitle = new Label("マイメモ");
                memoTitle.style.fontSize = 11;
                memoTitle.style.unityFontStyleAndWeight = FontStyle.Bold;
                memoTitle.style.marginBottom = 3;
                _detailScroll.Add(memoTitle);

                var memoBox = new Label(rec.memo);
                memoBox.style.fontSize = 11;
                memoBox.style.whiteSpace = WhiteSpace.Normal;
                memoBox.style.paddingLeft = 8;
                memoBox.style.paddingRight = 8;
                memoBox.style.paddingTop = 6;
                memoBox.style.paddingBottom = 6;
                memoBox.style.backgroundColor = Surface2Color;
                memoBox.style.borderTopLeftRadius = 6;
                memoBox.style.borderTopRightRadius = 6;
                memoBox.style.borderBottomLeftRadius = 6;
                memoBox.style.borderBottomRightRadius = 6;
                memoBox.style.marginBottom = 10;
                _detailScroll.Add(memoBox);
            }

            // Live project assets
            var livePaths = VamManifestStore.ResolveLivePaths(rec);
            var assetTitle = new Label($"プロジェクト内のファイル ({livePaths.Count} 件)");
            assetTitle.style.fontSize = 11;
            assetTitle.style.unityFontStyleAndWeight = FontStyle.Bold;
            assetTitle.style.marginBottom = 4;
            _detailScroll.Add(assetTitle);

            var filterRow = new VisualElement();
            filterRow.style.flexDirection = FlexDirection.Row;
            filterRow.style.flexWrap = Wrap.Wrap;
            filterRow.style.marginBottom = 6;

            var filters = new[]
            {
                ("all", "すべて"),
                ("prefab", "Prefab"),
                ("mat", "Material"),
                ("model", "Model"),
                ("tex", "Texture"),
                ("folder", "Folder")
            };
            foreach (var (key, label) in filters)
            {
                var fb = new Button(() =>
                {
                    _assetFilter = key;
                    RenderDetail();
                }) { text = label };
                fb.style.fontSize = 10;
                fb.style.paddingLeft = 6;
                fb.style.paddingRight = 6;
                fb.style.marginRight = 3;
                fb.style.marginBottom = 3;
                if (_assetFilter == key)
                {
                    fb.style.backgroundColor = AccentColor;
                    fb.style.color = Color.white;
                }
                filterRow.Add(fb);
            }
            _detailScroll.Add(filterRow);

            var filteredPaths = livePaths.Where(MatchesAssetFilter).ToList();
            if (filteredPaths.Count == 0)
            {
                var noAssets = new Label("表示できるファイルがありません（クリックでPing・ドラッグでSceneへ配置できます）");
                noAssets.style.fontSize = 11;
                noAssets.style.color = MutedColor;
                noAssets.style.whiteSpace = WhiteSpace.Normal;
                _detailScroll.Add(noAssets);
                return;
            }

            int shown = 0;
            foreach (var assetPath in filteredPaths)
            {
                if (shown >= 150)
                {
                    var more = new Label($"他 {filteredPaths.Count - shown} 件は省略されています（Project 窓でご確認ください）");
                    more.style.fontSize = 10;
                    more.style.color = MutedColor;
                    more.style.marginTop = 4;
                    _detailScroll.Add(more);
                    break;
                }
                _detailScroll.Add(CreateAssetRow(assetPath));
                shown++;
            }
        }

        private bool MatchesAssetFilter(string assetPath)
        {
            if (_assetFilter == "all") return true;
            bool isFolder = AssetDatabase.IsValidFolder(assetPath);
            if (_assetFilter == "folder") return isFolder;
            if (isFolder) return false;

            string ext = Path.GetExtension(assetPath).ToLowerInvariant();
            switch (_assetFilter)
            {
                case "prefab": return ext == ".prefab";
                case "mat": return ext == ".mat";
                case "model": return ext == ".fbx" || ext == ".obj" || ext == ".blend";
                case "tex": return ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".tga" || ext == ".psd";
                default: return true;
            }
        }

        private VisualElement CreateAssetRow(string assetPath)
        {
            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.alignItems = Align.Center;
            row.style.paddingLeft = 6;
            row.style.paddingRight = 6;
            row.style.paddingTop = 3;
            row.style.paddingBottom = 3;
            row.style.marginBottom = 2;
            row.style.backgroundColor = Surface2Color;
            row.style.borderTopLeftRadius = 4;
            row.style.borderTopRightRadius = 4;
            row.style.borderBottomLeftRadius = 4;
            row.style.borderBottomRightRadius = 4;
            row.tooltip = assetPath + "\nクリック: Project で選択 / ダブルクリック: 開く / ドラッグ: Scene へ配置";

            var obj = AssetDatabase.LoadMainAssetAtPath(assetPath);
            var iconTex = obj != null ? AssetPreview.GetMiniThumbnail(obj) : AssetDatabase.GetCachedIcon(assetPath);
            if (iconTex != null)
            {
                var ic = new Image { image = iconTex, scaleMode = ScaleMode.ScaleToFit };
                ic.style.width = 16;
                ic.style.height = 16;
                ic.style.marginRight = 6;
                ic.style.flexShrink = 0;
                row.Add(ic);
            }

            string name = Path.GetFileName(assetPath);
            var nameLbl = new Label(name);
            nameLbl.style.fontSize = 11;
            nameLbl.style.flexGrow = 1;
            nameLbl.style.overflow = Overflow.Hidden;
            nameLbl.style.textOverflow = TextOverflow.Ellipsis;
            row.Add(nameLbl);

            Vector2 pressPos = Vector2.zero;
            bool dragging = false;

            row.RegisterCallback<PointerDownEvent>(evt =>
            {
                if (evt.button != 0) return;
                pressPos = evt.position;
                dragging = false;
                if (evt.clickCount == 2 && obj != null)
                {
                    AssetDatabase.OpenAsset(obj);
                }
                else if (obj != null)
                {
                    Selection.activeObject = obj;
                    EditorGUIUtility.PingObject(obj);
                }
            });

            row.RegisterCallback<PointerMoveEvent>(evt =>
            {
                if (dragging || obj == null) return;
                if ((evt.pressedButtons & 1) == 0) return;
                if (Vector2.Distance(evt.position, pressPos) >= 6f)
                {
                    dragging = true;
                    DragAndDrop.PrepareStartDrag();
                    DragAndDrop.objectReferences = new[] { obj };
                    DragAndDrop.paths = new[] { assetPath };
                    DragAndDrop.StartDrag(obj.name);
                    evt.StopPropagation();
                }
            });

            return row;
        }

        private void ConfirmAndUninstall(InstalledAssetRecord rec)
        {
            var analysis = VamManifestStore.AnalyzeUninstall(_manifest, rec);
            int exclCount = analysis.exclusiveFilePaths.Count;
            int sharedCount = analysis.sharedPaths.Count;
            int refCount = analysis.referencedByPaths.Count;

            if (exclCount == 0 && analysis.exclusiveFolderPaths.Count == 0)
            {
                bool removeRecordOnly = EditorUtility.DisplayDialog(
                    "アンインストール確認",
                    $"「{rec.title}」の固有ファイルはプロジェクト内に残っていないか、他のアセットと共有されています（共有保護: {sharedCount} 件）。\n\n「導入済みアセット」一覧の記録だけ削除しますか？",
                    "記録を削除",
                    "キャンセル");
                if (removeRecordOnly)
                {
                    _manifest.assets.RemoveAll(a => string.Equals(a.itemId, rec.itemId, StringComparison.OrdinalIgnoreCase));
                    VamManifestStore.Save(_manifest);
                    _selectedItemId = "";
                    ReloadManifest();
                }
                return;
            }

            string refWarn = refCount > 0
                ? $"\n\n⚠ 注意: 他のシーンや Prefab など {refCount} 件から参照されています：\n・" +
                  string.Join("\n・", analysis.referencedByPaths.Take(5)) +
                  (refCount > 5 ? $"\n（ほか {refCount - 5} 件）" : "")
                : "";

            string msg =
                $"「{rec.title}」をプロジェクトからアンインストールします。\n\n" +
                $"・ゴミ箱へ移動するファイル: {exclCount} 件\n" +
                $"・他アセットと共有のため保護するファイル: {sharedCount} 件" +
                refWarn +
                "\n\nOS のゴミ箱へ移動します。よろしいですか？";

            if (!EditorUtility.DisplayDialog("アセットのアンインストール", msg, "ゴミ箱へ移動して削除", "キャンセル"))
            {
                return;
            }

            var (removed, failed) = VamManifestStore.ExecuteUninstall(_manifest, rec, analysis);
            _selectedItemId = "";
            ReloadManifest();
            if (failed.Count > 0)
            {
                ShowNotification(new GUIContent($"{removed} 件削除しました（失敗 {failed.Count} 件）"));
            }
            else
            {
                ShowNotification(new GUIContent($"「{rec.title}」を削除しました（{removed} 件）"));
            }
        }

        private Texture2D LoadThumbnail(string thumbPath)
        {
            if (string.IsNullOrEmpty(thumbPath) || !File.Exists(thumbPath)) return null;
            if (_thumbCache.TryGetValue(thumbPath, out var cached) && cached != null)
            {
                return cached;
            }

            try
            {
                byte[] bytes = File.ReadAllBytes(thumbPath);
                var tex = new Texture2D(2, 2, TextureFormat.RGBA32, false);
                if (ImageConversion.LoadImage(tex, bytes, false))
                {
                    _thumbCache[thumbPath] = tex;
                    return tex;
                }
                DestroyImmediate(tex);
            }
            catch
            {
                // Ignore corrupted thumbnails
            }
            return null;
        }
    }
}
