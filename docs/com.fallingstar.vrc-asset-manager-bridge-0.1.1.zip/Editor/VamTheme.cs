using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace VrcAssetManager.Bridge
{
    // Unity エディタ標準の配色（Personal / Pro スキンの両方）に合わせた色
    internal static class VamTheme
    {
        private static bool Dark => EditorGUIUtility.isProSkin;
        private static Color Hex(int rgb, float a = 1f) =>
            new Color(((rgb >> 16) & 0xFF) / 255f, ((rgb >> 8) & 0xFF) / 255f, (rgb & 0xFF) / 255f, a);

        // ウィンドウ・Inspector の背景
        public static Color Background => Dark ? Hex(0x383838) : Hex(0xC8C8C8);
        // ツールバー
        public static Color Toolbar => Dark ? Hex(0x3C3C3C) : Hex(0xCBCBCB);
        // カード・行など一段浮いた面
        public static Color Surface => Dark ? Hex(0x414141) : Hex(0xD6D6D6);
        // 画像の下地など一段沈んだ面
        public static Color Sunken => Dark ? Hex(0x2E2E2E) : Hex(0xBDBDBD);
        public static Color Border => Dark ? Hex(0x232323) : Hex(0x999999);
        public static Color Text => Dark ? Hex(0xD2D2D2) : Hex(0x090909);
        public static Color Muted => Dark ? Hex(0x9A9A9A) : Hex(0x555555);
        // 選択色（Project / Hierarchy の選択と同じ青）
        public static Color Selection => Dark ? Hex(0x2C5D87) : Hex(0x3A72B0);
        public static Color SelectionBorder => Dark ? Hex(0x4C8BD1) : Hex(0x3A72B0);
        public static Color SelectionText => Hex(0xFFFFFF);
        public static Color Danger => Dark ? Hex(0xE06C6C) : Hex(0xB02020);
        public static Color Online => Dark ? Hex(0x5CB85C) : Hex(0x2E8B2E);
        public static Color Offline => Dark ? Hex(0x777777) : Hex(0x888888);

        private static readonly Dictionary<string, string> DisplayCache = new Dictionary<string, string>();

        // Unity のエディタ用フォントで表示できない文字を整える。
        //  ・𝒔𝒎𝒐𝒌𝒚 のような装飾用アルファベット（数学用英数字）だけ通常の英数字に戻す（全角の（）！などはそのまま）
        //  ・🎀🎁 など基本多言語面の外にある絵文字、異体字セレクタ、結合用の文字は取り除く（□ になるため）
        public static string Display(string s)
        {
            if (string.IsNullOrEmpty(s)) return s ?? "";
            if (DisplayCache.TryGetValue(s, out var cached)) return cached;
            string n = s;
            var sb = new System.Text.StringBuilder(n.Length);
            bool lastSpace = false;
            for (int i = 0; i < n.Length; i++)
            {
                char c = n[i];
                if (char.IsHighSurrogate(c))
                {
                    if (i + 1 < n.Length && char.IsLowSurrogate(n[i + 1]))
                    {
                        int cp = char.ConvertToUtf32(c, n[i + 1]);
                        i++;
                        if (cp >= 0x1D400 && cp <= 0x1D7FF)
                        {
                            string folded;
                            try
                            {
                                folded = char.ConvertFromUtf32(cp).Normalize(System.Text.NormalizationForm.FormKC);
                            }
                            catch
                            {
                                folded = "";
                            }
                            if (folded.Length == 1 && folded[0] < 0x80)
                            {
                                sb.Append(folded);
                                lastSpace = false;
                            }
                        }
                    }
                    continue;
                }
                if (char.IsLowSurrogate(c)) continue;
                if (c == '\u200D' || c == '\uFE0E' || c == '\uFE0F' || c == '\u20E3') continue;
                // ✨ ⛄ ✦ などの記号系絵文字（よく使う ♥♡★☆♪♫ は残す）
                if (c >= '\u2600' && c <= '\u27BF' && "♥♡★☆♪♫".IndexOf(c) < 0) continue;
                if (c >= '\u2B00' && c <= '\u2BFF') continue;
                bool space = char.IsWhiteSpace(c);
                if (space && (lastSpace || sb.Length == 0)) continue;
                sb.Append(space ? ' ' : c);
                lastSpace = space;
            }
            string result = sb.ToString().Trim();
            if (result.Length == 0) result = s;
            if (DisplayCache.Count > 4000) DisplayCache.Clear();
            DisplayCache[s] = result;
            return result;
        }
    }
}

