using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace VrcAssetManager.Bridge
{
    public static class VamUnityPackageParser
    {
        public static List<PackageAssetEntry> ParseEntries(string packagePath)
        {
            var results = new List<PackageAssetEntry>();
            if (string.IsNullOrEmpty(packagePath) || !File.Exists(packagePath))
            {
                return results;
            }

            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using (var fs = new FileStream(packagePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var gz = new GZipStream(fs, CompressionMode.Decompress))
            {
                var header = new byte[512];
                string pendingLongName = null;
                string pendingPaxName = null;

                while (ReadExact(gz, header, 512) == 512)
                {
                    if (IsZeroBlock(header))
                    {
                        break;
                    }

                    string rawName = ReadTarString(header, 0, 100);
                    string prefix = ReadTarString(header, 345, 155);
                    if (!string.IsNullOrEmpty(prefix))
                    {
                        rawName = prefix + "/" + rawName;
                    }

                    char typeFlag = (char)header[156];
                    long size = ParseOctal(header, 124, 12);

                    string entryName = !string.IsNullOrEmpty(pendingPaxName)
                        ? pendingPaxName
                        : (!string.IsNullOrEmpty(pendingLongName) ? pendingLongName : rawName);

                    if (typeFlag != 'L' && typeFlag != 'x' && typeFlag != 'g')
                    {
                        pendingLongName = null;
                        pendingPaxName = null;
                    }

                    if (typeFlag == 'L')
                    {
                        byte[] buf = ReadPayload(gz, size);
                        SkipPadding(gz, size);
                        pendingLongName = Encoding.UTF8.GetString(buf).TrimEnd('\0', '\r', '\n');
                        continue;
                    }

                    if (typeFlag == 'x')
                    {
                        byte[] buf = ReadPayload(gz, size);
                        SkipPadding(gz, size);
                        pendingPaxName = ParsePaxPath(Encoding.UTF8.GetString(buf));
                        continue;
                    }

                    bool isRegular = typeFlag == '0' || typeFlag == '\0';
                    if (isRegular && TryMatchPathnameEntry(entryName, out string guid) && size > 0 && size <= 65536)
                    {
                        byte[] buf = ReadPayload(gz, size);
                        SkipPadding(gz, size);
                        string text = Encoding.UTF8.GetString(buf).TrimStart('\uFEFF');
                        string firstLine = "";
                        using (var sr = new StringReader(text))
                        {
                            firstLine = sr.ReadLine() ?? "";
                        }
                        firstLine = firstLine.Replace('\\', '/').Trim().TrimEnd('\0');
                        if (!string.IsNullOrEmpty(firstLine) && seen.Add(guid))
                        {
                            results.Add(new PackageAssetEntry
                            {
                                guid = guid,
                                assetPath = firstLine
                            });
                        }
                    }
                    else
                    {
                        SkipBytes(gz, size);
                        SkipPadding(gz, size);
                    }
                }
            }

            return results;
        }

        private static bool TryMatchPathnameEntry(string entryName, out string guid)
        {
            guid = null;
            if (string.IsNullOrEmpty(entryName)) return false;

            string norm = entryName.Replace('\\', '/').TrimStart('.');
            while (norm.StartsWith("/")) norm = norm.Substring(1);

            int slash = norm.IndexOf('/');
            if (slash != 32) return false;

            string g = norm.Substring(0, 32);
            string rest = norm.Substring(slash + 1);
            if (!string.Equals(rest, "pathname", StringComparison.OrdinalIgnoreCase)) return false;

            for (int i = 0; i < 32; i++)
            {
                char c = g[i];
                bool hex = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
                if (!hex) return false;
            }

            guid = g.ToLowerInvariant();
            return true;
        }

        private static string ParsePaxPath(string paxData)
        {
            if (string.IsNullOrEmpty(paxData)) return null;
            var lines = paxData.Split('\n');
            foreach (var line in lines)
            {
                int eq = line.IndexOf(" path=", StringComparison.Ordinal);
                if (eq >= 0)
                {
                    return line.Substring(eq + 6).TrimEnd('\r', '\0');
                }
            }
            return null;
        }

        private static int ReadExact(Stream s, byte[] buffer, int count)
        {
            int total = 0;
            while (total < count)
            {
                int n = s.Read(buffer, total, count - total);
                if (n <= 0) break;
                total += n;
            }
            return total;
        }

        private static byte[] ReadPayload(Stream s, long size)
        {
            if (size <= 0) return Array.Empty<byte>();
            var buf = new byte[(int)size];
            ReadExact(s, buf, (int)size);
            return buf;
        }

        private static void SkipPadding(Stream s, long size)
        {
            long rem = size % 512;
            if (rem > 0)
            {
                SkipBytes(s, 512 - rem);
            }
        }

        private static void SkipBytes(Stream s, long count)
        {
            if (count <= 0) return;
            var scratch = new byte[8192];
            long remaining = count;
            while (remaining > 0)
            {
                int chunk = remaining > scratch.Length ? scratch.Length : (int)remaining;
                int n = s.Read(scratch, 0, chunk);
                if (n <= 0) break;
                remaining -= n;
            }
        }

        private static bool IsZeroBlock(byte[] block)
        {
            for (int i = 0; i < block.Length; i++)
            {
                if (block[i] != 0) return false;
            }
            return true;
        }

        private static string ReadTarString(byte[] block, int offset, int length)
        {
            int end = offset;
            int max = offset + length;
            while (end < max && block[end] != 0)
            {
                end++;
            }
            return Encoding.UTF8.GetString(block, offset, end - offset);
        }

        private static long ParseOctal(byte[] block, int offset, int length)
        {
            // Support GNU base-256 size prefix when high bit is set
            if ((block[offset] & 0x80) != 0)
            {
                long v = block[offset] & 0x7F;
                for (int i = 1; i < length; i++)
                {
                    v = (v << 8) | block[offset + i];
                }
                return v;
            }

            long val = 0;
            int end = offset + length;
            for (int i = offset; i < end; i++)
            {
                byte b = block[i];
                if (b == 0 || b == (byte)' ') continue;
                if (b < (byte)'0' || b > (byte)'7') break;
                val = (val << 3) + (b - (byte)'0');
            }
            return val;
        }
    }
}
