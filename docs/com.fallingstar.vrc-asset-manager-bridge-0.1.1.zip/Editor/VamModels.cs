using System;
using System.Collections.Generic;

namespace VrcAssetManager.Bridge
{
    [Serializable]
    public class InstalledAssetRecord
    {
        public string itemId = "";
        public string boothId = "";
        public string title = "";
        public string shop = "";
        public string category = "";
        public string categoryLabel = "";
        public string subcategory = "";
        public string boothUrl = "";
        public string memo = "";
        public List<string> tags = new List<string>();
        public string version = "";
        public string sourcePath = "";
        public string sourceFile = "";
        public string thumbPath = "";
        public long installedAt;
        public string detectedBy = "import";
        public List<string> guids = new List<string>();
        public List<string> assetPaths = new List<string>();

        public void EnsureLists()
        {
            if (tags == null) tags = new List<string>();
            if (guids == null) guids = new List<string>();
            if (assetPaths == null) assetPaths = new List<string>();
        }
    }

    [Serializable]
    public class InstalledManifest
    {
        public int schemaVersion = 1;
        public string projectName = "";
        public string projectPath = "";
        public long updatedAt;
        public List<InstalledAssetRecord> assets = new List<InstalledAssetRecord>();

        public void EnsureLists()
        {
            if (assets == null) assets = new List<InstalledAssetRecord>();
            foreach (var a in assets)
            {
                a?.EnsureLists();
            }
        }
    }

    [Serializable]
    public class UnityInstanceEntry
    {
        public int pid;
        public string projectPath = "";
        public string projectName = "";
        public string unityVersion = "";
        public int port;
        public string token = "";
        public string bridgeVersion = "";
        public long startedAt;
        public long lastHeartbeat;
    }

    [Serializable]
    public class UnityInstanceRegistry
    {
        public int schemaVersion = 1;
        public List<UnityInstanceEntry> instances = new List<UnityInstanceEntry>();

        public void EnsureLists()
        {
            if (instances == null) instances = new List<UnityInstanceEntry>();
        }
    }

    [Serializable]
    public class ImportRequestPayload
    {
        public string jobId = "";
        public string packagePath = "";
        public bool interactive = true;
        public string cleanupTempDir = "";
        public InstalledAssetRecord record = new InstalledAssetRecord();
    }

    [Serializable]
    public class ImportStatusResponse
    {
        public string jobId = "";
        public string state = "idle";
        public string message = "";
        public int importedCount;
    }

    [Serializable]
    public class BridgeStatusResponse
    {
        public bool ok = true;
        public string projectPath = "";
        public string projectName = "";
        public string unityVersion = "";
        public string bridgeVersion = "";
        public int installedCount;
        public bool busy;
        public string currentJobId = "";
        public string currentJobState = "idle";
    }

    [Serializable]
    public class SyncManifestPayload
    {
        public bool replaceScanRecords = false;
        public List<InstalledAssetRecord> assets = new List<InstalledAssetRecord>();
    }

    [Serializable]
    public class OpenWindowPayload
    {
        public string itemId = "";
        public string boothId = "";
    }

    [Serializable]
    public class ApiSimpleResponse
    {
        public bool ok = true;
        public string message = "";
        public int count;
    }

    public class UninstallAnalysis
    {
        public List<string> exclusiveFilePaths = new List<string>();
        public List<string> exclusiveFolderPaths = new List<string>();
        public List<string> sharedPaths = new List<string>();
        public List<string> referencedByPaths = new List<string>();
    }

    public class PackageAssetEntry
    {
        public string guid;
        public string assetPath;
    }
}
