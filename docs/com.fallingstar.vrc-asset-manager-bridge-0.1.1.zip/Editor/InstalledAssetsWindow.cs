using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace VrcAssetManager.Bridge
{
    public class InstalledAssetsWindow : EditorWindow
    {
        private static event Action DataChanged;
        public static event Action DataChangedPublic;

        private InstalledManifest _manifest = new InstalledManifest();

        private string _searchQuery = "";
        private string _selectedCategory = "すべて";
        private string _sortMode = "recent";
        private string _selectedItemId = "";
        private string _pendingSelectItemId = "";
        private string _pendingSelectBoothId = "";

        private VisualElement _gridContainer;
        private Label _countLabel;
        private Label _bridgeLabel;
        private VisualElement _bridgeDot;
        private DropdownField _catDropdown;
        private TextField _searchField;

        [MenuItem("Tools/VRC Asset Manager/導入済みアセット", false, 100)]
        [MenuItem("Window/VRC Asset Manager/導入済みアセット", false, 2000)]
        public static void OpenWindow()
        {
            OpenAndSelect(null, null);
        }

        public static void OpenAndSelect(string itemId, string boothId)
        {
            var projectType = typeof(Editor).Assembly.GetType("UnityEditor.ProjectBrowser");
            var consoleType = typeof(Editor).Assembly.GetType("UnityEditor.ConsoleWindow");
            var dockTypes = new[] { projectType, consoleType }.Where(t => t != null).ToArray();

            var win = dockTypes.Length > 0
                ? GetWindow<InstalledAssetsWindow>("導入済みアセット", true, dockTypes)
                : GetWindow<InstalledAssetsWindow>("導入済みアセット", true);

            win.minSize = new Vector2(460, 280);
            if (!string.IsNullOrEmpty(itemId) || !string.IsNullOrEmpty(boothId))
            {
                win._pendingSelectItemId = itemId ?? "";
                win._pendingSelectBoothId = boothId ?? "";
                win.ReloadManifest();
            }
            win.Show();
            win.Focus();
        }

        public static void NotifyDataChanged()
        {
            DataChanged?.Invoke();
            DataChangedPublic?.Invoke();
        }

        public static void Notify(string message)
        {
            if (HasOpenInstances<InstalledAssetsWindow>())
            {
                GetWindow<InstalledAssetsWindow>(null, false).ShowNotification(new GUIContent(message));
            }
            else
            {
                Debug.Log("[VRC Asset Manager] " + message);
            }
        }

        private void OnEnable()
        {
            DataChanged += OnExternalDataChanged;
            Selection.selectionChanged += OnSelectionChanged;
            BuildUI();
            ReloadManifest();
        }

        // 別のアプリで記録が書き換わっていたら、ウィンドウに戻ったときに反映する
        private void OnFocus()
        {
            if (_manifest != null && !ReferenceEquals(_manifest, VamManifestStore.LoadCached()))
            {
                ReloadManifest();
            }
        }

        private void OnDisable()
        {
            DataChanged -= OnExternalDataChanged;
            Selection.selectionChanged -= OnSelectionChanged;
        }

        // Inspector の表示対象が変わったら、カードの選択枠もそれに合わせる
        private void OnSelectionChanged()
        {
            string id = VamAssetSelection.SelectedItemId;
            if (string.IsNullOrEmpty(id) || string.Equals(id, _selectedItemId, StringComparison.OrdinalIgnoreCase)) return;
            _selectedItemId = id;
            RenderGrid();
        }

        private void OnExternalDataChanged()
        {
            ReloadManifest();
        }

        private bool IsDark => EditorGUIUtility.isProSkin;
        private Color BgColor => VamTheme.Background;
        private Color SurfaceColor => VamTheme.Surface;
        private Color Surface2Color => VamTheme.Sunken;
        private Color BorderColor => VamTheme.Border;
        private Color TextColor => VamTheme.Text;
        private Color MutedColor => VamTheme.Muted;


        private void BuildUI()
        {
            rootVisualElement.Clear();
            rootVisualElement.style.flexGrow = 1;
            rootVisualElement.style.backgroundColor = BgColor;
            rootVisualElement.style.color = TextColor;

            // Top Toolbar
            var topBar = new VisualElement();
            topBar.style.flexDirection = FlexDirection.Row;
            topBar.style.alignItems = Align.Center;
            topBar.style.flexWrap = Wrap.Wrap;
            topBar.style.paddingLeft = 10;
            topBar.style.paddingRight = 10;
            topBar.style.paddingTop = 6;
            topBar.style.paddingBottom = 6;
            topBar.style.backgroundColor = VamTheme.Toolbar;
            topBar.style.borderBottomWidth = 1;
            topBar.style.borderBottomColor = BorderColor;

            var titleLbl = new Label("導入済みアセット");
            titleLbl.style.fontSize = 14;
            titleLbl.style.unityFontStyleAndWeight = FontStyle.Bold;
            titleLbl.style.marginRight = 8;
            topBar.Add(titleLbl);

            _countLabel = new Label("0 件");
            _countLabel.style.fontSize = 11;
            _countLabel.style.color = MutedColor;
            _countLabel.style.marginRight = 12;
            topBar.Add(_countLabel);

            _searchField = new TextField();
            _searchField.value = _searchQuery;
            _searchField.style.width = 190;
            _searchField.style.marginRight = 6;
            _searchField.tooltip = "商品名・ショップ名・メモで検索";
            _searchField.RegisterValueChangedCallback(evt =>
            {
                _searchQuery = evt.newValue ?? "";
                RenderGrid();
            });
            topBar.Add(_searchField);

            _catDropdown = new DropdownField(new List<string> { "すべて" }, 0);
            _catDropdown.style.width = 120;
            _catDropdown.style.marginRight = 6;
            _catDropdown.RegisterValueChangedCallback(evt =>
            {
                _selectedCategory = evt.newValue ?? "すべて";
                RenderGrid();
            });
            topBar.Add(_catDropdown);

            var sortChoices = new List<string> { "導入日時順", "名前順", "ショップ順" };
            var sortDropdown = new DropdownField(sortChoices, 0);
            sortDropdown.style.width = 105;
            sortDropdown.style.marginRight = 6;
            sortDropdown.RegisterValueChangedCallback(evt =>
            {
                if (evt.newValue == "名前順") _sortMode = "name";
                else if (evt.newValue == "ショップ順") _sortMode = "shop";
                else _sortMode = "recent";
                RenderGrid();
            });
            topBar.Add(sortDropdown);

            var reloadBtn = new Button(ReloadManifest) { text = "再読込" };
            reloadBtn.style.marginRight = 8;
            topBar.Add(reloadBtn);

            var spacer = new VisualElement();
            spacer.style.flexGrow = 1;
            topBar.Add(spacer);

            var statusBox = new VisualElement();
            statusBox.style.flexDirection = FlexDirection.Row;
            statusBox.style.alignItems = Align.Center;
            _bridgeDot = new VisualElement();
            _bridgeDot.style.width = 8;
            _bridgeDot.style.height = 8;
            _bridgeDot.style.borderTopLeftRadius = 4;
            _bridgeDot.style.borderTopRightRadius = 4;
            _bridgeDot.style.borderBottomLeftRadius = 4;
            _bridgeDot.style.borderBottomRightRadius = 4;
            _bridgeDot.style.marginRight = 5;
            statusBox.Add(_bridgeDot);

            _bridgeLabel = new Label();
            _bridgeLabel.style.fontSize = 11;
            _bridgeLabel.style.color = MutedColor;
            statusBox.Add(_bridgeLabel);
            topBar.Add(statusBox);

            rootVisualElement.Add(topBar);

            // Body Split
            var body = new VisualElement();
            body.style.flexDirection = FlexDirection.Row;
            body.style.flexGrow = 1;
            body.style.minHeight = 0;

            var gridScroll = new ScrollView(ScrollViewMode.Vertical);
            gridScroll.style.flexGrow = 1;
            gridScroll.style.flexBasis = 0;
            gridScroll.style.paddingLeft = 10;
            gridScroll.style.paddingRight = 10;
            gridScroll.style.paddingTop = 10;
            gridScroll.style.paddingBottom = 10;

            _gridContainer = new VisualElement();
            _gridContainer.style.flexDirection = FlexDirection.Row;
            _gridContainer.style.flexWrap = Wrap.Wrap;
            _gridContainer.style.alignItems = Align.FlexStart;
            gridScroll.Add(_gridContainer);
            body.Add(gridScroll);

            rootVisualElement.Add(body);
            UpdateBridgeStatus();
        }

        private void UpdateBridgeStatus()
        {
            if (_bridgeDot == null || _bridgeLabel == null) return;
            if (VamBridgeServer.IsRunning)
            {
                _bridgeDot.style.backgroundColor = VamTheme.Online;
                _bridgeLabel.text = "連携待機中";
            }
            else
            {
                _bridgeDot.style.backgroundColor = VamTheme.Offline;
                _bridgeLabel.text = "オフライン";
            }
        }

        private void ReloadManifest()
        {
            _manifest = VamManifestStore.LoadCached();
            UpdateBridgeStatus();
            RefreshCategories();
            ApplyPendingSelection();
            RenderGrid();
        }

        private void ApplyPendingSelection()
        {
            if (_manifest?.assets == null) return;
            if (string.IsNullOrEmpty(_pendingSelectItemId) && string.IsNullOrEmpty(_pendingSelectBoothId)) return;

            var hit = _manifest.assets.FirstOrDefault(a =>
                (!string.IsNullOrEmpty(_pendingSelectItemId) && string.Equals(a.itemId, _pendingSelectItemId, StringComparison.OrdinalIgnoreCase)) ||
                (!string.IsNullOrEmpty(_pendingSelectBoothId) && string.Equals(a.boothId, _pendingSelectBoothId, StringComparison.OrdinalIgnoreCase)));

            if (hit != null)
            {
                _selectedItemId = hit.itemId;
                _pendingSelectItemId = "";
                _pendingSelectBoothId = "";
                VamAssetSelection.Select(hit);
            }
        }

        private void RefreshCategories()
        {
            if (_catDropdown == null) return;
            var cats = new List<string> { "すべて" };
            var distinct = _manifest.assets
                .Select(a => string.IsNullOrEmpty(a.categoryLabel) ? a.category : a.categoryLabel)
                .Where(c => !string.IsNullOrWhiteSpace(c))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(c => c, StringComparer.CurrentCultureIgnoreCase);
            cats.AddRange(distinct);
            _catDropdown.choices = cats;
            if (!cats.Contains(_selectedCategory))
            {
                _selectedCategory = "すべて";
            }
            _catDropdown.SetValueWithoutNotify(_selectedCategory);
        }

        private List<InstalledAssetRecord> GetFilteredAssets()
        {
            IEnumerable<InstalledAssetRecord> q = _manifest.assets ?? new List<InstalledAssetRecord>();

            if (!string.IsNullOrEmpty(_selectedCategory) && _selectedCategory != "すべて")
            {
                q = q.Where(a =>
                {
                    string c = string.IsNullOrEmpty(a.categoryLabel) ? a.category : a.categoryLabel;
                    return string.Equals(c, _selectedCategory, StringComparison.OrdinalIgnoreCase);
                });
            }

            if (!string.IsNullOrWhiteSpace(_searchQuery))
            {
                string kw = _searchQuery.Trim().ToLowerInvariant();
                q = q.Where(a =>
                    (a.title ?? "").ToLowerInvariant().Contains(kw) ||
                    (a.shop ?? "").ToLowerInvariant().Contains(kw) ||
                    (a.memo ?? "").ToLowerInvariant().Contains(kw) ||
                    (a.tags != null && a.tags.Any(t => (t ?? "").ToLowerInvariant().Contains(kw))));
            }

            switch (_sortMode)
            {
                case "name":
                    q = q.OrderBy(a => a.title, StringComparer.CurrentCultureIgnoreCase);
                    break;
                case "shop":
                    q = q.OrderBy(a => a.shop, StringComparer.CurrentCultureIgnoreCase)
                         .ThenBy(a => a.title, StringComparer.CurrentCultureIgnoreCase);
                    break;
                default:
                    q = q.OrderByDescending(a => a.installedAt)
                         .ThenBy(a => a.title, StringComparer.CurrentCultureIgnoreCase);
                    break;
            }

            return q.ToList();
        }

        private void RenderGrid()
        {
            if (_gridContainer == null) return;
            _gridContainer.Clear();

            var items = GetFilteredAssets();
            _countLabel.text = $"{items.Count} / {_manifest.assets.Count} 件";

            if (items.Count == 0)
            {
                var emptyBox = new VisualElement();
                emptyBox.style.flexGrow = 1;
                emptyBox.style.paddingTop = 48;
                emptyBox.style.alignItems = Align.Center;

                string msg = _manifest.assets.Count == 0
                    ? "このプロジェクトにはまだ導入済みアセットが記録されていません。\n\nVRC Asset Manager から「Unityにインポート」または\n設定の「既存アセットを検出」を実行してください。"
                    : "検索条件に一致するアセットがありません。";
                var emptyLbl = new Label(msg);
                emptyLbl.style.unityTextAlign = TextAnchor.MiddleCenter;
                emptyLbl.style.color = MutedColor;
                emptyLbl.style.whiteSpace = WhiteSpace.Normal;
                emptyBox.Add(emptyLbl);
                _gridContainer.Add(emptyBox);
                return;
            }

            foreach (var rec in items)
            {
                _gridContainer.Add(CreateCard(rec));
            }
        }

        private VisualElement CreateCard(InstalledAssetRecord rec)
        {
            bool selected = !string.IsNullOrEmpty(_selectedItemId) &&
                            string.Equals(rec.itemId, _selectedItemId, StringComparison.OrdinalIgnoreCase);

            var card = new VisualElement();
            card.style.width = 166;
            // 全カードの高さをそろえる（タイトルの行数で下端がずれないように）
            card.style.height = 198;
            card.style.overflow = Overflow.Hidden;
            card.style.marginRight = 8;
            card.style.marginBottom = 8;
            card.style.paddingTop = 6;
            card.style.paddingBottom = 8;
            card.style.paddingLeft = 6;
            card.style.paddingRight = 6;
            card.style.backgroundColor = selected ? VamTheme.Selection : SurfaceColor;
            card.style.borderTopWidth = 1;
            card.style.borderRightWidth = 1;
            card.style.borderBottomWidth = 1;
            card.style.borderLeftWidth = 1;
            var bc = selected ? VamTheme.SelectionBorder : BorderColor;
            card.style.borderTopColor = bc;
            card.style.borderRightColor = bc;
            card.style.borderBottomColor = bc;
            card.style.borderLeftColor = bc;
            card.style.borderTopLeftRadius = 3;
            card.style.borderTopRightRadius = 3;
            card.style.borderBottomLeftRadius = 3;
            card.style.borderBottomRightRadius = 3;

            var imgWrap = new VisualElement();
            imgWrap.style.height = 112;
            imgWrap.style.backgroundColor = Surface2Color;
            imgWrap.style.borderTopLeftRadius = 3;
            imgWrap.style.borderTopRightRadius = 3;
            imgWrap.style.borderBottomLeftRadius = 3;
            imgWrap.style.borderBottomRightRadius = 3;
            imgWrap.style.marginBottom = 6;
            imgWrap.style.overflow = Overflow.Hidden;
            imgWrap.style.justifyContent = Justify.Center;
            imgWrap.style.alignItems = Align.Center;

            var ph = new Label(string.IsNullOrEmpty(rec.title) ? "Asset" : VamTheme.Display(rec.title));
            ph.style.fontSize = 11;
            ph.style.color = MutedColor;
            ph.style.unityTextAlign = TextAnchor.MiddleCenter;
            ph.style.whiteSpace = WhiteSpace.Normal;
            imgWrap.Add(ph);
            if (!string.IsNullOrEmpty(rec.thumbPath))
            {
                var img = new Image { scaleMode = ScaleMode.ScaleAndCrop };
                img.style.position = Position.Absolute;
                img.style.left = 0;
                img.style.top = 0;
                img.style.right = 0;
                img.style.bottom = 0;
                img.style.display = DisplayStyle.None;
                imgWrap.Add(img);
                VamAssetDetailView.RequestThumbnail(rec.thumbPath, t =>
                {
                    if (t == null) return;
                    img.image = t;
                    img.style.display = DisplayStyle.Flex;
                    ph.style.display = DisplayStyle.None;
                });
            }

            if (rec.detectedBy == "scan")
            {
                var badge = new Label("自動検出");
                badge.style.position = Position.Absolute;
                badge.style.top = 4;
                badge.style.left = 4;
                badge.style.fontSize = 9;
                badge.style.color = VamTheme.Text;
                badge.style.backgroundColor = new Color(0f, 0f, 0f, 0.55f);
                badge.style.paddingLeft = 5;
                badge.style.paddingRight = 5;
                badge.style.paddingTop = 1;
                badge.style.paddingBottom = 1;
                badge.style.borderTopLeftRadius = 4;
                badge.style.borderTopRightRadius = 4;
                badge.style.borderBottomLeftRadius = 4;
                badge.style.borderBottomRightRadius = 4;
                imgWrap.Add(badge);
            }

            card.Add(imgWrap);

            string catText = string.IsNullOrEmpty(rec.categoryLabel) ? rec.category : rec.categoryLabel;
            {
                // カテゴリーが無くても行の高さは確保する
                var catLbl = new Label(VamTheme.Display(catText ?? ""));
                catLbl.style.fontSize = 10;
                catLbl.style.color = selected ? VamTheme.SelectionText : MutedColor;
                catLbl.style.marginBottom = 2;
                catLbl.style.height = 14;
                catLbl.style.overflow = Overflow.Hidden;
                catLbl.style.textOverflow = TextOverflow.Ellipsis;
                catLbl.style.whiteSpace = WhiteSpace.NoWrap;
                card.Add(catLbl);
            }

            var titleLbl = new Label(string.IsNullOrEmpty(rec.title) ? "(名称未設定)" : VamTheme.Display(rec.title));
            titleLbl.tooltip = VamTheme.Display(rec.title);
            titleLbl.style.fontSize = 12;
            if (selected) titleLbl.style.color = VamTheme.SelectionText;
            titleLbl.style.unityFontStyleAndWeight = FontStyle.Bold;
            titleLbl.style.whiteSpace = WhiteSpace.NoWrap;
            titleLbl.style.textOverflow = TextOverflow.Ellipsis;
            titleLbl.style.height = 16; // 1行で固定し、はみ出す分は「…」
            titleLbl.style.overflow = Overflow.Hidden;
            titleLbl.style.marginBottom = 3;
            card.Add(titleLbl);

            string sub = string.IsNullOrEmpty(rec.shop) ? "-" : rec.shop;
            if (!string.IsNullOrEmpty(rec.version))
            {
                sub += $" · {rec.version}";
            }
            var shopLbl = new Label(VamTheme.Display(sub));
            shopLbl.style.fontSize = 10;
            shopLbl.style.color = selected ? VamTheme.SelectionText : MutedColor;
            shopLbl.style.overflow = Overflow.Hidden;
            shopLbl.style.textOverflow = TextOverflow.Ellipsis;
            shopLbl.style.whiteSpace = WhiteSpace.NoWrap;
            shopLbl.style.marginTop = StyleKeyword.Auto; // カードの一番下にそろえる
            card.Add(shopLbl);

            card.RegisterCallback<MouseDownEvent>(evt =>
            {
                if (evt.button != 0) return;
                _selectedItemId = rec.itemId;
                RenderGrid();
                VamAssetSelection.Select(rec);
                if (evt.clickCount == 2)
                {
                    RevealAssetFolder(rec);
                }
            });

            return card;
        }

        // アセットの導入先フォルダを Project ウィンドウで開く
        public static void RevealAssetFolder(InstalledAssetRecord rec)
        {
            string folder = FindAssetRootFolder(rec);
            if (string.IsNullOrEmpty(folder))
            {
                EditorUtility.DisplayDialog("導入済みアセット", "このアセットのフォルダがプロジェクト内に見つかりません。", "OK");
                return;
            }
            var obj = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(folder);
            if (obj == null) return;
            EditorUtility.FocusProjectWindow();
            // フォルダを OpenAsset すると Project ウィンドウがそのフォルダの中身を表示する
            AssetDatabase.OpenAsset(obj);
            EditorGUIUtility.PingObject(obj);
        }

        private static string FindAssetRootFolder(InstalledAssetRecord rec)
        {
            var dirs = (rec.assetPaths ?? new List<string>())
                .Where(p => !string.IsNullOrEmpty(p) && VamManifestStore.AssetExistsOnDisk(p))
                .Select(p => AssetDatabase.IsValidFolder(p) ? p : Path.GetDirectoryName(p)?.Replace('\\', '/'))
                .Where(d => !string.IsNullOrEmpty(d) && d.StartsWith("Assets", StringComparison.OrdinalIgnoreCase))
                .ToList();
            if (dirs.Count == 0) return "";

            // すべてのファイルに共通する一番深いフォルダ
            var parts = dirs[0].Split('/');
            int common = parts.Length;
            foreach (var d in dirs.Skip(1))
            {
                var p = d.Split('/');
                int i = 0;
                while (i < common && i < p.Length && string.Equals(parts[i], p[i], StringComparison.OrdinalIgnoreCase)) i++;
                common = i;
            }
            string root = string.Join("/", parts.Take(common));
            if (common >= 2 && AssetDatabase.IsValidFolder(root)) return root;

            // Assets 直下にばらけている場合は、一番多くのファイルを含む Assets/<名前> を選ぶ
            var top = dirs
                .Select(d => d.Split('/'))
                .Where(p => p.Length >= 2)
                .GroupBy(p => p[0] + "/" + p[1], StringComparer.OrdinalIgnoreCase)
                .OrderByDescending(g => g.Count())
                .Select(g => g.Key)
                .FirstOrDefault(AssetDatabase.IsValidFolder);
            return top ?? "Assets";
        }

    }
}
