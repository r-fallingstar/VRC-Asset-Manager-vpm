using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace VrcAssetManager.Bridge
{
    // 「導入済みアセット」で選んだアセットを Inspector に表示するための選択用オブジェクト
    public class VamAssetSelection : ScriptableObject
    {
        public string itemId = "";

        private static VamAssetSelection _instance;
        internal static event System.Action ItemChanged;

        public static void Select(InstalledAssetRecord rec)
        {
            if (rec == null) return;
            if (_instance == null)
            {
                _instance = CreateInstance<VamAssetSelection>();
                _instance.hideFlags = HideFlags.DontSave;
            }
            bool alreadySelected = Selection.activeObject == _instance;
            // 同じアセットを選び直した（ダブルクリックなど）ときは何もしない
            if (alreadySelected && string.Equals(_instance.itemId, rec.itemId, System.StringComparison.OrdinalIgnoreCase)) return;

            _instance.itemId = rec.itemId;
            _instance.name = string.IsNullOrEmpty(rec.title) ? "導入済みアセット" : VamTheme.Display(rec.title);
            if (alreadySelected)
            {
                // Inspector を作り直さず、中身だけ差し替える
                ItemChanged .Invoke();
            }
            else
            {
                Selection.activeObject = _instance;
            }
        }

        public static string SelectedItemId =>
            Selection.activeObject is VamAssetSelection s ? s.itemId : "";
    }

    [CustomEditor(typeof(VamAssetSelection))]
    public class VamAssetSelectionEditor : UnityEditor.Editor
    {
        private VisualElement _root;

        public override VisualElement CreateInspectorGUI()
        {
            _root = new VisualElement();
            InstalledAssetsWindow.DataChangedPublic += Redraw;
            VamAssetSelection.ItemChanged += Redraw;
            Redraw();
            return _root;
        }

        private void OnDisable()
        {
            InstalledAssetsWindow.DataChangedPublic -= Redraw;
            VamAssetSelection.ItemChanged -= Redraw;
        }

        private void Redraw()
        {
            if (_root == null || target == null) return;
            VamAssetDetailView.Render(_root, ((VamAssetSelection)target).itemId);
        }

        protected override void OnHeaderGUI()
        {
            // toolbar スタイルは高さが固定で日本語が上下に切れるため、通常の行として描く
            GUILayout.Space(4);
            GUILayout.BeginHorizontal();
            GUILayout.Space(6);
            GUILayout.Label("VRC Asset Manager ・ 導入済みアセット", HeaderStyle, GUILayout.Height(22));
            GUILayout.EndHorizontal();
            var r = GUILayoutUtility.GetRect(1, 1, GUILayout.ExpandWidth(true));
            EditorGUI.DrawRect(r, new Color(0f, 0f, 0f, 0.25f));
        }

        private static GUIStyle _headerStyle;
        private static GUIStyle HeaderStyle => _headerStyle ??= new GUIStyle(EditorStyles.boldLabel)
        {
            alignment = TextAnchor.MiddleLeft,
            fontSize = 12,
            clipping = TextClipping.Clip,
        };
    }
}

