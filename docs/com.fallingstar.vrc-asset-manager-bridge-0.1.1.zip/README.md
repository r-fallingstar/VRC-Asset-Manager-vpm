# VRC Asset Manager Bridge

VRC Asset Manager（v1.1.0 以降）と Unity プロジェクトを連携するための Editor 拡張パッケージです。

## 主な機能
- **ワンクリック導入**: VRC Asset Manager 側のダウンロードファイル欄から起動中の Unity へ `.unitypackage`（または `.zip` 内の一時展開パッケージ）を直接インポート
- **導入済みアセットタブ**: Unity の `Tools > VRC Asset Manager > 導入済みアセット`（初期位置は Project / Console タブの並び）から、BOOTH 商品情報・サムネイル・メモ付きで導入済みアセットを一覧管理
- **ドラッグ＆ドロップ / Ping / BOOTH 連携**: アセット一覧から Prefab や Material を Scene / Hierarchy へ直接ドラッグ配置、クリックで Project 窓へジャンプ、BOOTH ページや元フォルダを開く操作に対応
- **安全なアンインストール**: 他アセットとの共有ファイルおよび外部シーン・Prefab からの参照をチェックしたうえでゴミ箱へ移動

## 対応環境
- Unity 2022.3 LTS（VRChat SDK3 Avatars / Worlds）
